# Build V3 APK with Termux on Samsung Tablet

## 📱 Step-by-Step Termux Guide

### Step 1: Install Termux
1. **Download Termux** from Google Play Store or F-Droid
2. **Open Termux** app on your Samsung tablet

### Step 2: Setup Development Environment
```bash
# Update package lists
pkg update && pkg upgrade -y

# Install essential tools
pkg install nodejs npm git python build-essential -y

# Install Java (required for Android builds)
pkg install openjdk-17 -y

# Verify installations
node --version
npm --version
git --version
```

### Step 3: Clone Your Project
```bash
# Clone from GitHub (replace with your repo URL)
git clone https://github.com/yourusername/v3-search.git

# Or download project files if not on GitHub
# Navigate to your project
cd v3-search/mobile
```

### Step 4: Install Project Dependencies
```bash
# Install mobile app dependencies
npm install

# Install Expo CLI and EAS CLI
npm install -g @expo/cli@latest @expo/eas-cli@latest

# Fix any permission issues
npm config set prefix ~/.local
export PATH=$PATH:~/.local/bin
```

### Step 5: Login to Expo
```bash
# Create free Expo account or login
expo login

# Follow prompts to enter:
# - Email address
# - Password
# - Username (if creating new account)
```

### Step 6: Configure Project
```bash
# Initialize EAS configuration
eas build:configure

# This creates eas.json with build profiles
```

### Step 7: Build APK
```bash
# Build APK for testing (faster)
eas build --profile preview --platform android

# OR build production APK (optimized)
eas build --profile production --platform android
```

### Step 8: Download and Install
1. **Wait for build completion** (5-10 minutes)
2. **Copy download URL** from terminal output
3. **Open URL in browser** to download APK
4. **Install APK** by tapping the downloaded file

## 🔧 Troubleshooting

### If npm install fails:
```bash
# Clear npm cache
npm cache clean --force

# Remove node_modules and reinstall
rm -rf node_modules
npm install
```

### If Expo login fails:
```bash
# Logout and try again
expo logout
expo login
```

### If build fails:
```bash
# Clear EAS cache
eas build --profile preview --platform android --clear-cache
```

### If Java errors occur:
```bash
# Set JAVA_HOME
export JAVA_HOME=/data/data/com.termux/files/usr/opt/openjdk
echo 'export JAVA_HOME=/data/data/com.termux/files/usr/opt/openjdk' >> ~/.bashrc
```

## 📋 Complete Command Sequence

Here's the full sequence for copy/paste:

```bash
# 1. Setup
pkg update && pkg upgrade -y
pkg install nodejs npm git python build-essential openjdk-17 -y

# 2. Get project
git clone https://github.com/yourusername/v3-search.git
cd v3-search/mobile

# 3. Install dependencies
npm install
npm install -g @expo/cli@latest @expo/eas-cli@latest

# 4. Build
expo login
eas build:configure
eas build --profile preview --platform android
```

## 📱 APK Features

Your built APK will include:
- Complete V3 search engine
- Google & Microsoft OAuth login
- Email/password authentication
- Bookmarks management
- Search history
- Opera GX-style themes
- Mobile-optimized interface
- Offline bookmark access

## 💡 Pro Tips

1. **Keep Termux open** during build process
2. **Connect to WiFi** for faster downloads
3. **Enable storage permission** in Termux settings
4. **Use external keyboard** for easier typing
5. **Copy commands** from this guide to avoid typos

## 🚀 After Building

1. **Test APK** on your tablet
2. **Share with friends** for testing
3. **Upload to Google Play** (optional)
4. **Create new versions** by running build again

Your APK will be ready to install and use independently of any web servers!