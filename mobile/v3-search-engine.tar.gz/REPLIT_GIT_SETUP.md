# Set Up Git Version Control in Replit

## 🚀 Using Git Commands in Replit Shell/Console

Since the Version Control tab isn't visible, we can use Git commands directly:

### Step 1: Initialize and Configure Git
```bash
# Configure Git with your details
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# Check current status
git status

# Add all files to staging
git add .

# Make initial commit
git commit -m "Initial V3 search engine commit"
```

### Step 2: Create GitHub Repository
1. **Go to github.com** in your browser
2. **Click "New repository"**
3. **Name:** `v3-search-engine`
4. **Keep Public**
5. **Don't initialize** with README
6. **Copy the repository URL** (looks like: `https://github.com/username/v3-search-engine.git`)

### Step 3: Connect to GitHub
```bash
# Add GitHub as remote origin
git remote add origin https://github.com/YOUR_USERNAME/v3-search-engine.git

# Push your code to GitHub
git branch -M main
git push -u origin main
```

### Step 4: Verify Upload
Go to your GitHub repository URL and you should see all your files uploaded.

## Alternative: Use Replit's Built-in Git

If you prefer the visual interface:

### Look for Version Control in Different Places:
1. **Left sidebar** - Look for Git icon
2. **Tools menu** - Click "Tools" → "Git"
3. **Command palette** - Press `Ctrl+K` or `Cmd+K` and type "git"
4. **Bottom panel** - Look for Git/Source Control tab

### If Found, Follow These Steps:
1. **Click "Initialize Repository"** or "Create Git Repo"
2. **Stage all files** (select all changed files)
3. **Add commit message:** `Initial V3 search engine commit`
4. **Commit changes**
5. **Connect to GitHub** (look for GitHub icon or "Publish" button)
6. **Create new repository** named `v3-search-engine`
7. **Push to GitHub**

## Quick Commands for Shell Method

Copy and paste these commands one by one in Replit's Shell:

```bash
# 1. Setup
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# 2. Commit
git add .
git commit -m "V3 Search Engine - Initial commit"

# 3. Connect to GitHub (replace with your URL)
git remote add origin https://github.com/YOUR_USERNAME/v3-search-engine.git
git branch -M main
git push -u origin main
```

## Your GitHub URL
After successful push, your repository will be available at:
```
https://github.com/YOUR_USERNAME/v3-search-engine
```

Use this URL in Termux to clone and build your APK!

## Troubleshooting

### If git push fails:
```bash
# First time setup might need authentication
git config --global credential.helper store
git push -u origin main
```

### If remote already exists:
```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/v3-search-engine.git
git push -u origin main
```

This method gives you full Git version control and uploads your V3 project to GitHub!