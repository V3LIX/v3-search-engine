# 🚀 Build V3 APK on Samsung Tablet - Simple Guide

## Method 1: Using Samsung Internet Browser + Replit

### Step 1: Open Replit Shell
1. **Open this Replit project** in Samsung Internet browser
2. **Click "Shell" tab** (bottom of screen)
3. **Run commands one by one:**

```bash
# Go to mobile folder
cd mobile

# Install dependencies (may take 2-3 minutes)
npm install

# Install Expo CLI globally
npm install -g @expo/cli@latest eas-cli@latest

# Initialize project
npx expo install --fix

# Login to Expo (create free account)
npx expo login

# Build APK (cloud build - takes 5-10 minutes)
eas build --profile preview --platform android
```

### Step 2: Download APK
- **Wait for build completion** (you'll see a download link)
- **Click the download link** in browser
- **APK downloads to your tablet**

### Step 3: Install APK
1. **Go to Downloads folder** on tablet
2. **Tap the V3-xxx.apk file**
3. **Allow installation from unknown sources** if prompted
4. **Install and enjoy your V3 search app!**

## Method 2: Using Termux App (Alternative)

### Step 1: Install Termux
1. **Download Termux** from Google Play Store
2. **Open Termux** and run setup:

```bash
# Update packages
pkg update && pkg upgrade -y

# Install Node.js and tools
pkg install nodejs npm git -y

# Clone your project
git clone https://github.com/[your-username]/[your-repo].git
cd [your-repo]/mobile

# Install dependencies
npm install

# Install build tools
npm install -g @expo/cli@latest eas-cli@latest

# Login to Expo
expo login

# Build APK
eas build --profile preview --platform android
```

## Method 3: GitHub Actions (Zero Setup)

If the above methods don't work:

1. **Push your code to GitHub**
2. **Go to your GitHub repo** in browser
3. **Click "Actions" tab**
4. **Click "Run workflow"**
5. **Download APK** from artifacts when complete

## 📱 What You'll Get

Your V3.apk will include:
- ✅ Complete search engine
- ✅ Google & Microsoft login
- ✅ Email/password authentication
- ✅ Bookmarks management
- ✅ Search history
- ✅ Opera GX-style themes
- ✅ Mobile-optimized interface
- ✅ Offline bookmark access

## 🔧 Troubleshooting

### If Expo login fails:
```bash
# Clear cache and retry
npx expo logout
npx expo login
```

### If build fails:
```bash
# Clear cache and retry
eas build --profile preview --platform android --clear-cache
```

### If npm install fails:
```bash
# Clear cache
npm cache clean --force
rm -rf node_modules
npm install
```

## ⚡ Quick Summary

**Fastest method for Samsung tablet:**
1. Open Replit in browser
2. Use Shell tab
3. Run build commands
4. Download APK
5. Install on tablet

Your APK will be ~50-100MB and work completely offline for saved content!

## 📲 Testing Your APK

1. **Install APK** on tablet
2. **Test login** (Google, Microsoft, Email)
3. **Try search functionality**
4. **Test bookmarks and history**
5. **Check all themes work**

Ready to build your V3 search engine APK! 🎉