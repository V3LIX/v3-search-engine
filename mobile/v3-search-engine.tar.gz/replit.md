# V3 - Search Engine

## Overview

V3 is a full-stack search engine designed to provide web search capabilities. The application features a modern React frontend with a comprehensive component library, Express.js backend, PostgreSQL database with Drizzle ORM, and integrated Replit authentication.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (July 15, 2025)

✓ Implemented toggleable search filters with collapsible interface
✓ Enhanced theme provider with dark/light mode toggle and custom background options
✓ Added custom animated backgrounds (gradient, particles, waves, geometric)
✓ Created comprehensive settings panel for theme and background customization
✓ Implemented full bookmarks functionality with CRUD operations
✓ Added bookmarks database table and API routes
✓ Created dedicated bookmarks page with category filtering and search
✓ Enhanced navigation with bookmarks link in header
✓ Prepared application for deployment to custom domain
✓ Created complete mobile app for Google Play Store
✓ Added comprehensive deployment guide for mobile app publishing
✓ Implemented Google Chrome-style search categories (All, Images, Videos, Short Videos, News, Maps)
✓ Removed "Private AI Search" branding to create Google-like clean interface
✓ Enhanced search backend to handle different categories with relevant results
✓ Updated mobile app with simplified branding and authentication
✓ **Completed compact mobile-friendly search interface implementation**
✓ Added mobile-responsive search form with optimized sizing and spacing
✓ Implemented horizontal scrollable category buttons with mobile-specific styling
✓ Enhanced mobile navigation with collapsible filters and AI assistant
✓ Fixed category switching functionality for all search types
✓ Optimized search results layout for mobile devices with compact design
✓ Fixed background theme system to properly apply to body element
✓ Added mobile-specific header navigation with dropdown menu integration
✓ Removed white background option and implemented custom image background as default
✓ Updated theme system to use user-provided background image instead of blue gradient
✓ Modified search categories to only appear after performing a search (Google Chrome behavior)
✓ Enhanced search interface to show clean homepage until user searches
✓ Improved background image quality with high-quality rendering and anti-aliasing
✓ Added mobile scrolling support for background selection in settings panel
✓ Enhanced mobile performance with optimized background attachment and smooth scrolling
✓ **Completely redesigned all backgrounds with custom Opera GX-style themes**
✓ Created 6 unique animated gaming backgrounds with neon accents and dark aesthetics
✓ Implemented advanced CSS animations and gradient effects for immersive experience
✓ Added cyberpunk-inspired color schemes with magenta, cyan, and orange neon highlights
✓ **Enhanced neon particles with brighter glow effects and color customization system**
✓ Implemented 6 color schemes: Default, Ocean Blue, Matrix Green, Fire Orange, Royal Purple, Rainbow
✓ Added dynamic color-changing animations for particles with brightness and saturation effects
✓ Created comprehensive color variation system for all background types with theme persistence
✓ Fixed spinning screen issue with safe animation system that prevents CSS transition conflicts
✓ **Completed comprehensive authentication system with multiple login options**
✓ Implemented Google OAuth integration with user-provided credentials
✓ Added Microsoft OAuth with proper Windows branding and authentication flow
✓ Created secure email/password registration with bcrypt password hashing
✓ Added Google Password Manager integration with proper autocomplete attributes
✓ Updated database schema to support passwordHash field for credential storage
✓ **Created complete APK build guides for mobile app deployment**
✓ Developed Termux-based APK building process for Samsung tablet
✓ Added comprehensive GitHub upload guide for project distribution
✓ Created detailed mobile app deployment documentation with multiple build methods

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with CSS variables for theming
- **UI Components**: Comprehensive shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js with custom middleware for logging and error handling
- **Authentication**: Replit OIDC authentication with session management
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple

### Data Storage Solutions
- **Primary Database**: PostgreSQL (configured for Neon serverless)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Session Store**: PostgreSQL table for session persistence
- **Bookmarks Storage**: User bookmarks with categories, tags, and privacy settings
- **File Structure**: Shared schema definitions between client and server

## Key Components

### Authentication System
- Replit OIDC integration for secure authentication
- Session-based authentication with PostgreSQL storage
- User profile management with admin role support
- Automatic session cleanup and security headers

### Search Engine Core
- Mock search functionality (ready for real search engine integration)
- Search query tracking and history
- Search result storage and management
- Advanced filtering capabilities (date, site, content type)

### AI Assistant Integration
- Chat session management for AI interactions
- Context-aware responses based on search results
- Mock AI responses (ready for real AI service integration)
- Conversation history tracking

### User Interface
- Responsive design with mobile-first approach
- Advanced theme system with dark/light/system modes
- Custom animated backgrounds (gradient, particles, waves, geometric)
- Comprehensive settings panel for appearance customization
- Component-based architecture with reusable UI elements
- Toggleable search filters with collapsible interface
- Real-time search suggestions and filtering
- Bookmarks management with categories and search
- Admin dashboard for system management

## Data Flow

### Search Process
1. User submits search query through React frontend
2. Query processed by Express backend with authentication check
3. Search parameters stored in PostgreSQL database
4. Mock search results generated (placeholder for real search engine)
5. Results stored in database and returned to frontend
6. Frontend displays results with sorting and filtering options

### AI Assistant Flow
1. User initiates AI conversation from search results
2. Chat session created and linked to search query
3. AI processing (currently mocked, ready for real AI integration)
4. Responses stored in database for conversation history
5. Real-time updates displayed in chat interface

### Authentication Flow
1. User redirects to Replit OIDC provider
2. Authentication callback processed by backend
3. User session created in PostgreSQL
4. Frontend receives authentication state via API
5. Protected routes accessible based on authentication status

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver
- **drizzle-orm**: Type-safe ORM for database operations
- **express**: Web application framework
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight React router

### UI Dependencies
- **@radix-ui/***: Comprehensive set of UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for components
- **lucide-react**: Icon library

### Authentication Dependencies
- **openid-client**: OpenID Connect client for Replit auth
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

## Deployment Strategy

### Development Environment
- Vite development server with HMR support
- Express server with auto-reload using tsx
- Replit development banner integration
- Error overlay for runtime error debugging

### Production Build
- Vite builds optimized React application to `dist/public`
- esbuild bundles Express server to `dist/index.js`
- Static file serving from Express for production deployment
- Environment variable configuration for database and authentication

### Custom Domain Deployment
- Application ready for deployment to custom domain
- All authentication configured for multi-domain support
- Database and session storage configured for production
- Custom backgrounds and theme system fully implemented
- All features tested and working in development environment

### Database Setup
- Drizzle migrations in `./migrations` directory
- Schema definitions in `./shared/schema.ts`
- Database push command for development: `npm run db:push`
- PostgreSQL connection via DATABASE_URL environment variable

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **SESSION_SECRET**: Session encryption key (required)
- **REPLIT_DOMAINS**: Allowed domains for Replit auth (required)
- **ISSUER_URL**: OIDC issuer URL (defaults to Replit)
- **REPL_ID**: Replit environment identifier

The architecture is designed for easy extension with real search engine APIs and AI services while maintaining privacy-first principles and robust authentication.