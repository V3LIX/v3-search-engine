import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { SettingsPanel } from "@/components/settings-panel";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/components/ui/theme-provider";
import { useIsMobile } from "@/hooks/use-mobile";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { AuthModal } from "@/components/auth-modal";
import { 
  Search, 
  Moon, 
  Sun, 
  Bot, 
  History, 
  Bookmark, 
  Download, 
  Send, 
  ChevronRight,
  Settings,
  User,
  ExternalLink,
  Clock,
  Globe,
  Filter,
  ChevronDown,
  ChevronUp,
  LogOut,
  BarChart3,
  Image,
  Video,
  Newspaper,
  Map,
  Play,
  FileText,
  Menu
} from "lucide-react";

interface SearchResult {
  id: number;
  title: string;
  url: string;
  description: string;
  domain: string;
  contentType: string;
  publishedDate: string;
  rank: number;
  saved: boolean;
  imageUrl?: string;
  thumbnailUrl?: string;
}

interface SearchResponse {
  searchQuery: {
    id: number;
    query: string;
  };
  results: SearchResult[];
  stats: {
    total: number;
    duration: number;
  };
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();
  const [showAuthModal, setShowAuthModal] = useState(false);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [currentQueryId, setCurrentQueryId] = useState<number | null>(null);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searchStats, setSearchStats] = useState<{ total: number; duration: number } | null>(null);
  const [aiMessage, setAiMessage] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [showAI, setShowAI] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  
  // Search filters
  const [dateFilter, setDateFilter] = useState("any");
  const [typeFilter, setTypeFilter] = useState("all");
  const [siteFilter, setSiteFilter] = useState("");
  const [searchCategory, setSearchCategory] = useState("all");

  // Search mutation
  const searchMutation = useMutation({
    mutationFn: async ({ query, filters }: { query: string; filters: any }) => {
      const searchFilters = {
        ...filters,
        category: searchCategory,
        dateFilter,
        typeFilter,
        siteFilter
      };
      const response = await apiRequest("POST", "/api/search", { query, filters: searchFilters });
      return response.json() as Promise<SearchResponse>;
    },
    onSuccess: (data) => {
      setSearchResults(data.results);
      setSearchStats(data.stats);
      setCurrentQueryId(data.searchQuery.id);
      setShowAI(true);
      
      // Generate AI summary
      if (data.results.length > 0) {
        const summaryMessage: ChatMessage = {
          role: 'assistant',
          content: `I found ${data.results.length} relevant results for "${data.searchQuery.query}". The search covered various sources including ${[...new Set(data.results.map(r => r.domain))].slice(0, 3).join(', ')}. Would you like me to summarize any specific result or answer questions about this topic?`,
          timestamp: new Date().toISOString()
        };
        setChatMessages([summaryMessage]);
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Search Failed",
        description: "An error occurred while searching. Please try again.",
        variant: "destructive",
      });
    },
  });

  // AI chat mutation
  const aiChatMutation = useMutation({
    mutationFn: async ({ message, queryId }: { message: string; queryId?: number }) => {
      const response = await apiRequest("POST", "/api/ai/chat", { message, queryId });
      return response.json() as Promise<{ response: string; sessionId: number; messages: ChatMessage[] }>;
    },
    onSuccess: (data) => {
      setChatMessages(data.messages);
      setAiMessage("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "AI Chat Failed",
        description: "Failed to get AI response. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Save result mutation
  const saveResultMutation = useMutation({
    mutationFn: async (resultId: number) => {
      const response = await apiRequest("POST", `/api/results/${resultId}/save`);
      return response.json() as Promise<{ saved: boolean }>;
    },
    onSuccess: (data, resultId) => {
      setSearchResults(prev => 
        prev.map(result => 
          result.id === resultId 
            ? { ...result, saved: data.saved }
            : result
        )
      );
      toast({
        title: data.saved ? "Result Saved" : "Result Removed",
        description: data.saved ? "Added to your saved results" : "Removed from saved results",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save result. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getSearchPlaceholder = () => {
    switch (searchCategory) {
      case "images": return "Search for images...";
      case "videos": return "Search for videos...";
      case "shorts": return "Search for short videos...";
      case "news": return "Search latest news...";
      case "maps": return "Search places and locations...";
      default: return "Search anything...";
    }
  };

  const handleSearch = (e?: React.FormEvent, overrideCategory?: string) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim()) return;

    const currentCategory = overrideCategory || searchCategory;
    const filters: any = {};
    if (dateFilter !== "any") filters.date = dateFilter;
    if (typeFilter !== "all") filters.type = typeFilter;
    if (siteFilter.trim()) filters.site = siteFilter.trim();
    if (currentCategory !== "all") filters.category = currentCategory;

    searchMutation.mutate({ query: searchQuery.trim(), filters });
  };

  // Auto-search when category changes (if we already have results)
  useEffect(() => {
    if (searchResults.length > 0 && searchQuery.trim()) {
      handleSearch(undefined, searchCategory);
    }
  }, [searchCategory]);

  const handleAIMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiMessage.trim()) return;

    aiChatMutation.mutate({ 
      message: aiMessage.trim(), 
      queryId: currentQueryId || undefined 
    });
  };

  const toggleSaveResult = (resultId: number) => {
    saveResultMutation.mutate(resultId);
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Less than an hour ago";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays} days ago`;
    
    return date.toLocaleDateString();
  };

  return (
    <div className="min-h-screen transition-colors duration-200">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">V3</span>
              </div>
            </div>
            
            {/* Navigation and Controls */}
            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex space-x-6">
                <Link href="/" className="text-blue-600 dark:text-blue-400 font-medium">
                  Search
                </Link>
                <Link href="/bookmarks" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 transition-colors">
                  Bookmarks
                </Link>
                <Link href="/history" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 transition-colors">
                  History
                </Link>
              </nav>
              
              {/* Theme Toggle */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="text-gray-600 dark:text-gray-300"
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              
              {/* Settings Panel */}
              <SettingsPanel />
              
              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center space-x-2 text-gray-600 dark:text-gray-300"
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.profileImageUrl} />
                      <AvatarFallback>
                        {user?.firstName?.charAt(0) || user?.email?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden md:inline">
                      {user?.firstName || user?.email || "User"}
                    </span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-3 py-2">
                    <p className="text-sm font-medium">{user?.firstName} {user?.lastName}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{user?.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </DropdownMenuItem>
                  <Link href="/admin">
                    <DropdownMenuItem>
                      <BarChart3 className="mr-2 h-4 w-4" />
                      Admin Dashboard
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => window.location.href = "/api/logout"}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className={`max-w-7xl mx-auto ${isMobile ? 'px-2 py-4' : 'px-4 sm:px-6 lg:px-8 py-8'}`}>
        {/* Search Interface */}
        <div className="mb-8">
          {/* Search Header */}
          <div className="text-center mb-8">
          </div>
          
          {/* Search Form */}
          <div className="max-w-4xl mx-auto">
            <Card className={`${isMobile ? 'p-4' : 'p-6'}`}>
              <form onSubmit={handleSearch} className="space-y-4">
                {/* Main Search Input */}
                <div className="relative">
                  <Search className={`absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 ${isMobile ? 'h-4 w-4' : 'h-5 w-5'}`} />
                  <Input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={getSearchPlaceholder()}
                    className={`pl-12 ${isMobile ? 'pr-20 py-3 text-base' : 'pr-32 py-4 text-lg'}`}
                  />
                  <Button 
                    type="submit" 
                    className="absolute right-2 top-1/2 transform -translate-y-1/2"
                    disabled={searchMutation.isPending}
                    size={isMobile ? "sm" : "default"}
                  >
                    {searchMutation.isPending ? (isMobile ? "..." : "Searching...") : (isMobile ? "Go" : "Search")}
                  </Button>
                </div>

                {/* Search Categories - Horizontal Scrollable (Only show after search) */}
                {searchResults.length > 0 && (
                  <div className={`flex overflow-x-auto gap-2 pb-2 border-b border-gray-200 dark:border-gray-700 ${isMobile ? 'scrollbar-hide' : ''}`}>
                    <Button
                    type="button"
                    variant={searchCategory === "all" ? "default" : "ghost"}
                    size={isMobile ? "sm" : "sm"}
                    onClick={() => {
                      setSearchCategory("all");
                      if (searchQuery.trim()) {
                        handleSearch(undefined, "all");
                      }
                    }}
                    className={`flex items-center gap-2 whitespace-nowrap ${isMobile ? 'px-3 py-1' : ''}`}
                  >
                    <Search className="h-4 w-4" />
                    {isMobile ? "All" : "All"}
                  </Button>
                    <Button
                      type="button"
                      variant={searchCategory === "images" ? "default" : "ghost"}
                      size={isMobile ? "sm" : "sm"}
                      onClick={() => {
                        setSearchCategory("images");
                        if (searchQuery.trim()) {
                          handleSearch(undefined, "images");
                        }
                      }}
                      className={`flex items-center gap-2 whitespace-nowrap ${isMobile ? 'px-3 py-1' : ''}`}
                    >
                      <Image className="h-4 w-4" />
                      {isMobile ? "Images" : "Images"}
                    </Button>
                    <Button
                      type="button"
                      variant={searchCategory === "videos" ? "default" : "ghost"}
                      size={isMobile ? "sm" : "sm"}
                      onClick={() => {
                        setSearchCategory("videos");
                        if (searchQuery.trim()) {
                          handleSearch(undefined, "videos");
                        }
                      }}
                      className={`flex items-center gap-2 whitespace-nowrap ${isMobile ? 'px-3 py-1' : ''}`}
                    >
                      <Video className="h-4 w-4" />
                      {isMobile ? "Videos" : "Videos"}
                    </Button>
                    <Button
                      type="button"
                      variant={searchCategory === "shorts" ? "default" : "ghost"}
                      size={isMobile ? "sm" : "sm"}
                      onClick={() => {
                        setSearchCategory("shorts");
                        if (searchQuery.trim()) {
                          handleSearch(undefined, "shorts");
                        }
                      }}
                      className={`flex items-center gap-2 whitespace-nowrap ${isMobile ? 'px-3 py-1' : ''}`}
                    >
                      <Play className="h-4 w-4" />
                      {isMobile ? "Shorts" : "Short Videos"}
                    </Button>
                    <Button
                      type="button"
                      variant={searchCategory === "news" ? "default" : "ghost"}
                      size={isMobile ? "sm" : "sm"}
                      onClick={() => {
                        setSearchCategory("news");
                        if (searchQuery.trim()) {
                          handleSearch(undefined, "news");
                        }
                      }}
                      className={`flex items-center gap-2 whitespace-nowrap ${isMobile ? 'px-3 py-1' : ''}`}
                    >
                      <Newspaper className="h-4 w-4" />
                      {isMobile ? "News" : "News"}
                    </Button>
                    <Button
                      type="button"
                      variant={searchCategory === "maps" ? "default" : "ghost"}
                      size={isMobile ? "sm" : "sm"}
                      onClick={() => {
                        setSearchCategory("maps");
                        if (searchQuery.trim()) {
                          handleSearch(undefined, "maps");
                        }
                      }}
                      className={`flex items-center gap-2 whitespace-nowrap ${isMobile ? 'px-3 py-1' : ''}`}
                    >
                      <Map className="h-4 w-4" />
                      {isMobile ? "Maps" : "Maps"}
                    </Button>
                  </div>
                )}
                
                {/* Filter and AI Toggle Buttons */}
                <div className={`flex ${isMobile ? 'flex-col gap-2' : 'flex-wrap gap-3 items-center justify-between'}`}>
                  <div className={`flex ${isMobile ? 'justify-center' : 'gap-3'} gap-3`}>
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => setShowFilters(!showFilters)}
                      className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
                      size={isMobile ? "sm" : "default"}
                    >
                      <Filter className={`mr-2 h-4 w-4`} />
                      {isMobile ? "Filters" : "Filters"}
                      {showFilters ? (
                        <ChevronUp className="ml-2 h-4 w-4" />
                      ) : (
                        <ChevronDown className="ml-2 h-4 w-4" />
                      )}
                    </Button>
                    
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => setShowAI(!showAI)}
                      className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                      size={isMobile ? "sm" : "default"}
                    >
                      <Bot className={`mr-2 h-4 w-4`} />
                      {isMobile ? "AI" : "AI Assistant"}
                    </Button>
                  </div>
                  
                  {/* Active filters indicator */}
                  {(dateFilter !== "any" || typeFilter !== "all" || siteFilter.trim()) && (
                    <div className={`flex items-center text-sm text-blue-600 dark:text-blue-400 ${isMobile ? 'justify-center' : ''}`}>
                      <Filter className="mr-1 h-3 w-3" />
                      Filters active
                    </div>
                  )}
                </div>

                {/* Collapsible Search Filters */}
                {showFilters && (
                  <div className="border-t border-gray-200 dark:border-gray-700 pt-4 space-y-4">
                    <div className="flex flex-wrap gap-4 items-center">
                      <div className="flex items-center space-x-2">
                        <label className="text-sm text-gray-600 dark:text-gray-400 font-medium">Date:</label>
                        <Select value={dateFilter} onValueChange={setDateFilter}>
                          <SelectTrigger className="w-36">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="any">Any time</SelectItem>
                            <SelectItem value="hour">Past hour</SelectItem>
                            <SelectItem value="day">Past 24 hours</SelectItem>
                            <SelectItem value="week">Past week</SelectItem>
                            <SelectItem value="month">Past month</SelectItem>
                            <SelectItem value="year">Past year</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <label className="text-sm text-gray-600 dark:text-gray-400 font-medium">Type:</label>
                        <Select value={typeFilter} onValueChange={setTypeFilter}>
                          <SelectTrigger className="w-36">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All results</SelectItem>
                            <SelectItem value="web">Web pages</SelectItem>
                            <SelectItem value="images">Images</SelectItem>
                            <SelectItem value="videos">Videos</SelectItem>
                            <SelectItem value="news">News</SelectItem>
                            <SelectItem value="pdf">PDFs</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <label className="text-sm text-gray-600 dark:text-gray-400 font-medium">Site:</label>
                        <Input
                          type="text"
                          value={siteFilter}
                          onChange={(e) => setSiteFilter(e.target.value)}
                          placeholder="site:example.com"
                          className="w-44"
                        />
                      </div>
                      
                      {/* Clear filters button */}
                      {(dateFilter !== "any" || typeFilter !== "all" || siteFilter.trim()) && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setDateFilter("any");
                            setTypeFilter("all");
                            setSiteFilter("");
                          }}
                          className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400"
                        >
                          Clear Filters
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </form>
            </Card>
          </div>
        </div>

        {/* Results Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Search Results */}
          <div className="lg:col-span-2">
            {searchStats && (
              <div className="mb-6">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  About {searchStats.total.toLocaleString()} results ({searchStats.duration.toFixed(2)} seconds)
                </p>
              </div>
            )}
            
            {searchMutation.isPending && (
              <div className="space-y-6">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="p-6">
                    <div className="animate-pulse">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full"></div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
            
            {/* Results List */}
            <div className={searchCategory === "images" ? "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" : "space-y-6"}>
              {searchResults.map((result) => (
                searchCategory === "images" ? (
                  // Image Grid Layout
                  <Card key={result.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer">
                    <div className="aspect-[4/3] relative overflow-hidden">
                      <img
                        src={result.thumbnailUrl || result.imageUrl || result.url}
                        alt={result.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = `https://via.placeholder.com/300x200/4f46e5/white?text=${encodeURIComponent(result.title.slice(0, 20))}`;
                        }}
                        onClick={() => window.open(result.imageUrl || result.url, '_blank')}
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                      
                      {/* Save button overlay */}
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <Button
                          variant="secondary"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleSaveResult(result.id);
                          }}
                          className={`h-8 w-8 ${result.saved ? "text-blue-600 bg-blue-50" : "text-gray-600 bg-white/90"}`}
                        >
                          <Bookmark className={`h-4 w-4 ${result.saved ? "fill-current" : ""}`} />
                        </Button>
                      </div>
                    </div>
                    
                    {/* Image info */}
                    <div className="p-3">
                      <h3 className="font-medium text-sm text-gray-900 dark:text-white line-clamp-2 mb-1">
                        {result.title}
                      </h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1">
                        {result.domain}
                      </p>
                    </div>
                  </Card>
                ) : (
                  // Standard List Layout
                  <Card key={result.id} className="p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <p className="text-sm text-green-600 dark:text-green-400 mb-1">
                          {result.url}
                        </p>
                        <h3 className="text-xl font-semibold text-blue-600 hover:text-blue-700 transition-colors mb-2">
                          <a href={result.url} target="_blank" rel="noopener noreferrer" className="flex items-center">
                            {result.title}
                            <ExternalLink className="ml-2 h-4 w-4" />
                          </a>
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                          {result.description}
                        </p>
                      </div>
                      <div className="ml-4 flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleSaveResult(result.id)}
                          className={result.saved ? "text-blue-600" : "text-gray-400 hover:text-gray-600"}
                        >
                          <Bookmark className={`h-5 w-5 ${result.saved ? "fill-current" : ""}`} />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                      <span className="flex items-center">
                        <Clock className="mr-1 h-3 w-3" />
                        {formatTimeAgo(result.publishedDate)}
                      </span>
                      <span>•</span>
                      <span className="flex items-center">
                        <Globe className="mr-1 h-3 w-3" />
                        {result.contentType}
                      </span>
                      <span>•</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setAiMessage(`Tell me more about: ${result.title}`);
                          setShowAI(true);
                        }}
                        className="text-blue-600 hover:text-blue-700 p-0 h-auto"
                      >
                        Ask AI about this
                      </Button>
                    </div>
                  </Card>
                )
              ))}
            </div>
          </div>

          {/* AI Assistant */}
          {showAI && (
            <div className="lg:col-span-1">
              <Card className="sticky top-8">
                {/* AI Panel Header */}
                <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Bot className="text-blue-600 h-5 w-5" />
                      <h3 className="font-semibold text-gray-900 dark:text-white">AI Assistant</h3>
                      <Badge variant="secondary" className="text-xs">LOCAL</Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setShowAI(false)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                {/* AI Chat Area */}
                <div className="p-4">
                  <div className="space-y-4 mb-4 max-h-96 overflow-y-auto">
                    {chatMessages.map((message, index) => (
                      <div
                        key={index}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`rounded-lg px-3 py-2 max-w-xs ${
                            message.role === 'user'
                              ? 'bg-blue-600 text-white'
                              : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-gray-100'
                          }`}
                        >
                          <p className="text-sm">{message.content}</p>
                        </div>
                      </div>
                    ))}
                    
                    {aiChatMutation.isPending && (
                      <div className="flex justify-start">
                        <div className="bg-gray-100 dark:bg-gray-700 rounded-lg px-3 py-2">
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* AI Input */}
                  <div className="border-t border-gray-200 dark:border-gray-700 pt-3">
                    <form onSubmit={handleAIMessage} className="flex space-x-2">
                      <Input
                        type="text"
                        value={aiMessage}
                        onChange={(e) => setAiMessage(e.target.value)}
                        placeholder="Ask AI anything..."
                        className="flex-1"
                        disabled={aiChatMutation.isPending}
                      />
                      <Button 
                        type="submit" 
                        size="icon"
                        disabled={aiChatMutation.isPending}
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </form>
                  </div>
                </div>
              </Card>
              
              {/* Quick Actions */}
              <Card className="mt-6 p-4">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-3">Quick Actions</h4>
                <div className="space-y-2">
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-gray-600 dark:text-gray-400"
                  >
                    <History className="mr-2 h-4 w-4" />
                    View Search History
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-gray-600 dark:text-gray-400"
                  >
                    <Bookmark className="mr-2 h-4 w-4" />
                    Saved Results
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-gray-600 dark:text-gray-400"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Export Data
                  </Button>
                </div>
              </Card>
            </div>
          )}
        </div>
      </main>

      {/* Authentication Modal */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />
    </div>
  );
}
