import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import {
  Search,
  Users,
  Bot,
  FileText,
  RefreshCw,
  Trash2,
  Download,
  UserCog,
  X,
  TrendingUp,
  Clock,
  Globe,
} from "lucide-react";
import { useLocation } from "wouter";

interface AdminStats {
  totalSearches: number;
  totalUsers: number;
  aiQueries: number;
  indexedPages: number;
}

interface PopularSearch {
  query: string;
  count: number;
}

interface RecentSearch {
  id: number;
  query: string;
  timestamp: string;
  resultsCount: number;
  user?: {
    firstName?: string;
    lastName?: string;
    email?: string;
  };
}

export default function Admin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [isOpen, setIsOpen] = useState(true);

  // Check if user is admin
  if (!user?.isAdmin) {
    setLocation("/");
    return null;
  }

  // Fetch admin stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
    retry: false,
  });

  // Fetch popular searches
  const { data: popularSearches, isLoading: popularLoading } = useQuery({
    queryKey: ["/api/admin/popular-searches"],
    retry: false,
  });

  // Fetch recent searches
  const { data: recentSearches, isLoading: recentLoading } = useQuery({
    queryKey: ["/api/admin/recent-searches"],
    retry: false,
  });

  // Reindex mutation
  const reindexMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/admin/reindex");
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: data.message,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to reindex content",
        variant: "destructive",
      });
    },
  });

  // Clear cache mutation
  const clearCacheMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/admin/clear-cache");
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: data.message,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to clear cache",
        variant: "destructive",
      });
    },
  });

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={() => setIsOpen(false)}>
      <div 
        className="absolute inset-y-0 right-0 w-full max-w-4xl bg-white dark:bg-gray-800 shadow-xl overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Admin Header */}
        <div className="p-6 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <UserCog className="h-5 w-5 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">V3LIX Management Console</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
            >
              <X className="h-6 w-6" />
            </Button>
          </div>
        </div>

        {/* Admin Content */}
        <div className="p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-600 dark:text-blue-400 font-medium">Total Searches</p>
                    <p className="text-3xl font-bold text-blue-800 dark:text-blue-200">
                      {statsLoading ? "..." : (stats?.totalSearches || 0).toLocaleString()}
                    </p>
                  </div>
                  <Search className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-600 dark:text-green-400 font-medium">Indexed Pages</p>
                    <p className="text-3xl font-bold text-green-800 dark:text-green-200">
                      {statsLoading ? "..." : (stats?.indexedPages || 0).toLocaleString()}
                    </p>
                  </div>
                  <FileText className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">AI Queries</p>
                    <p className="text-3xl font-bold text-purple-800 dark:text-purple-200">
                      {statsLoading ? "..." : (stats?.aiQueries || 0).toLocaleString()}
                    </p>
                  </div>
                  <Bot className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-orange-600 dark:text-orange-400 font-medium">Active Users</p>
                    <p className="text-3xl font-bold text-orange-800 dark:text-orange-200">
                      {statsLoading ? "..." : (stats?.totalUsers || 0).toLocaleString()}
                    </p>
                  </div>
                  <Users className="h-8 w-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Admin Tabs */}
          <Tabs defaultValue="analytics" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="analytics">Search Analytics</TabsTrigger>
              <TabsTrigger value="management">Index Management</TabsTrigger>
              <TabsTrigger value="system">System Health</TabsTrigger>
            </TabsList>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Popular Searches */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="mr-2 h-5 w-5" />
                      Popular Search Terms
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {popularLoading ? (
                      <div className="space-y-3">
                        {[1, 2, 3].map((i) => (
                          <div key={i} className="animate-pulse">
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {popularSearches?.map((search: PopularSearch, index: number) => (
                          <div key={index} className="flex items-center justify-between">
                            <span className="text-gray-900 dark:text-gray-100 font-medium">
                              {search.query}
                            </span>
                            <Badge variant="secondary">
                              {search.count} searches
                            </Badge>
                          </div>
                        ))}
                        {(!popularSearches || popularSearches.length === 0) && (
                          <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                            No search data available
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Recent Activity */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Clock className="mr-2 h-5 w-5" />
                      Recent Search Activity
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {recentLoading ? (
                      <div className="space-y-3">
                        {[1, 2, 3].map((i) => (
                          <div key={i} className="animate-pulse">
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                            <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {recentSearches?.map((search: RecentSearch) => (
                          <div key={search.id} className="border-l-4 border-blue-500 pl-3">
                            <div className="flex items-center justify-between text-sm">
                              <div className="flex-1">
                                <p className="font-medium text-gray-900 dark:text-gray-100">
                                  "{search.query}"
                                </p>
                                <div className="flex items-center space-x-2 text-gray-500 dark:text-gray-400 text-xs">
                                  <span>{formatTimeAgo(search.timestamp)}</span>
                                  <span>•</span>
                                  <span>{search.resultsCount} results</span>
                                  {search.user && (
                                    <>
                                      <span>•</span>
                                      <span>
                                        {search.user.firstName || search.user.email || "Anonymous"}
                                      </span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                        {(!recentSearches || recentSearches.length === 0) && (
                          <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                            No recent search activity
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="management" className="space-y-6">
              {/* System Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Index Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button
                      onClick={() => reindexMutation.mutate()}
                      disabled={reindexMutation.isPending}
                      className="p-6 h-auto flex flex-col items-start bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/30"
                      variant="outline"
                    >
                      <RefreshCw className={`mb-2 h-6 w-6 ${reindexMutation.isPending ? "animate-spin" : ""}`} />
                      <div className="text-left">
                        <div className="font-medium">
                          {reindexMutation.isPending ? "Re-indexing..." : "Re-index Content"}
                        </div>
                        <div className="text-xs opacity-75">Update search index</div>
                      </div>
                    </Button>

                    <Button
                      onClick={() => clearCacheMutation.mutate()}
                      disabled={clearCacheMutation.isPending}
                      className="p-6 h-auto flex flex-col items-start bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 border-green-200 dark:border-green-800 hover:bg-green-100 dark:hover:bg-green-900/30"
                      variant="outline"
                    >
                      <Trash2 className="mb-2 h-6 w-6" />
                      <div className="text-left">
                        <div className="font-medium">
                          {clearCacheMutation.isPending ? "Clearing..." : "Clear Cache"}
                        </div>
                        <div className="text-xs opacity-75">Free up storage space</div>
                      </div>
                    </Button>

                    <Button
                      className="p-6 h-auto flex flex-col items-start bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                      variant="outline"
                    >
                      <Download className="mb-2 h-6 w-6" />
                      <div className="text-left">
                        <div className="font-medium">Export Logs</div>
                        <div className="text-xs opacity-75">Download system logs</div>
                      </div>
                    </Button>

                    <Button
                      className="p-6 h-auto flex flex-col items-start bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400 border-orange-200 dark:border-orange-800 hover:bg-orange-100 dark:hover:bg-orange-900/30"
                      variant="outline"
                    >
                      <UserCog className="mb-2 h-6 w-6" />
                      <div className="text-left">
                        <div className="font-medium">Manage Users</div>
                        <div className="text-xs opacity-75">User administration</div>
                      </div>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="system" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="mr-2 h-5 w-5" />
                    System Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="font-medium text-gray-900 dark:text-gray-100">Search Engine</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                        Operational
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="font-medium text-gray-900 dark:text-gray-100">AI Assistant</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                        Operational
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="font-medium text-gray-900 dark:text-gray-100">Database</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                        Operational
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="font-medium text-gray-900 dark:text-gray-100">Web Crawler</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                        Operational
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
