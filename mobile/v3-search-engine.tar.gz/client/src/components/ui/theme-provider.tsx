import { createContext, useContext, useEffect, useState } from "react";

type Theme = "dark" | "light" | "system";
type Background = "custom" | "gradient" | "particles" | "waves" | "geometric" | "opera-gx";
type BackgroundColor = "default" | "blue" | "green" | "orange" | "purple" | "rainbow";

type ThemeProviderProps = {
  children: React.ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
};

type ThemeProviderState = {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  background: Background;
  setBackground: (background: Background) => void;
  backgroundColorVariant: BackgroundColor;
  setBackgroundColorVariant: (variant: BackgroundColor) => void;
};

const initialState: ThemeProviderState = {
  theme: "system",
  setTheme: () => null,
  background: "custom",
  setBackground: () => null,
  backgroundColorVariant: "default",
  setBackgroundColorVariant: () => null,
};

const ThemeProviderContext = createContext<ThemeProviderState>(initialState);

export function ThemeProvider({
  children,
  defaultTheme = "system",
  storageKey = "vite-ui-theme",
  ...props
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(
    () => (localStorage.getItem(storageKey) as Theme) || defaultTheme
  );
  const [background, setBackground] = useState<Background>(
    () => (localStorage.getItem("v3-background") as Background) || "custom"
  );
  const [backgroundColorVariant, setBackgroundColorVariant] = useState<BackgroundColor>(
    () => (localStorage.getItem("v3-background-color") as BackgroundColor) || "default"
  );

  useEffect(() => {
    const root = window.document.documentElement;
    const body = window.document.body;

    // Force reflow to prevent transition conflicts
    body.style.transition = 'none';
    body.offsetHeight; // Trigger reflow

    root.classList.remove("light", "dark");
    body.classList.remove("bg-custom", "bg-gradient", "bg-particles", "bg-waves", "bg-geometric", "bg-opera-gx");
    body.classList.remove("color-blue", "color-green", "color-orange", "color-purple", "color-rainbow");

    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)")
        .matches
        ? "dark"
        : "light";

      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme);
    }

    // Add background class after a small delay to prevent conflicts
    requestAnimationFrame(() => {
      const backgroundClass = `bg-${background}`;
      const colorClass = backgroundColorVariant !== "default" ? `color-${backgroundColorVariant}` : "";
      
      body.classList.add(backgroundClass);
      if (colorClass) {
        body.classList.add(colorClass);
      }
      // Keep transition disabled for backgrounds
      body.style.transition = '';
    });
  }, [theme, background, backgroundColorVariant]);

  const value = {
    theme,
    setTheme: (theme: Theme) => {
      localStorage.setItem(storageKey, theme);
      setTheme(theme);
    },
    background,
    setBackground: (background: Background) => {
      localStorage.setItem("v3-background", background);
      setBackground(background);
    },
    backgroundColorVariant,
    setBackgroundColorVariant: (variant: BackgroundColor) => {
      localStorage.setItem("v3-background-color", variant);
      setBackgroundColorVariant(variant);
    },
  };

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);

  if (context === undefined)
    throw new Error("useTheme must be used within a ThemeProvider");

  return context;
};
