import { useState } from "react";
import { useTheme } from "@/components/ui/theme-provider";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Settings, Sun, Moon, Monitor, Palette, Sparkles, Waves, Grid3X3, Layers } from "lucide-react";

export function SettingsPanel() {
  const { theme, setTheme, background, setBackground, backgroundColorVariant, setBackgroundColorVariant } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  const themeOptions = [
    { value: "light", label: "Light", icon: Sun },
    { value: "dark", label: "Dark", icon: Moon },
    { value: "system", label: "System", icon: Monitor },
  ];

  const backgroundOptions = [
    { value: "custom", label: "Neon Gaming", icon: Layers, description: "Dark gaming theme with neon accents" },
    { value: "gradient", label: "Cyber Gradient", icon: Palette, description: "Animated cyberpunk gradient" },
    { value: "particles", label: "Neon Particles", icon: Sparkles, description: "Floating neon particle effects" },
    { value: "waves", label: "Digital Waves", icon: Waves, description: "Animated neon wave patterns" },
    { value: "geometric", label: "Cyber Grid", icon: Grid3X3, description: "Futuristic geometric patterns" },
    { value: "opera-gx", label: "Opera GX Pro", icon: Sparkles, description: "Ultimate gaming experience" },
  ];

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
        >
          <Settings className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <SheetTitle>Appearance Settings</SheetTitle>
          <SheetDescription>
            Customize your V3 experience with themes and backgrounds
          </SheetDescription>
        </SheetHeader>
        
        <div className="space-y-6 mt-6 max-h-[calc(100vh-200px)] overflow-y-auto scrollbar-thin touch-scroll">
          {/* Theme Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Theme</CardTitle>
              <CardDescription>
                Choose your preferred color scheme
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                {themeOptions.map((option) => {
                  const Icon = option.icon;
                  return (
                    <Button
                      key={option.value}
                      variant={theme === option.value ? "default" : "outline"}
                      className="h-20 flex-col space-y-2"
                      onClick={() => setTheme(option.value as any)}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="text-sm">{option.label}</span>
                    </Button>
                  );
                })}
              </div>
              
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="text-xs">
                  Current: {themeOptions.find(opt => opt.value === theme)?.label}
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Background Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Background Style</CardTitle>
              <CardDescription>
                Choose a background effect for your search interface
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Color Variant Selection */}
              <div className="mb-6">
                <label className="text-sm font-medium mb-3 block">Color Scheme</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: "default", label: "Default", colors: ["bg-gradient-to-r", "from-pink-500", "to-cyan-500"] },
                    { value: "blue", label: "Ocean Blue", colors: ["bg-gradient-to-r", "from-blue-500", "to-cyan-400"] },
                    { value: "green", label: "Matrix Green", colors: ["bg-gradient-to-r", "from-green-500", "to-lime-400"] },
                    { value: "orange", label: "Fire Orange", colors: ["bg-gradient-to-r", "from-orange-500", "to-yellow-400"] },
                    { value: "purple", label: "Royal Purple", colors: ["bg-gradient-to-r", "from-purple-500", "to-pink-500"] },
                    { value: "rainbow", label: "Rainbow", colors: ["bg-gradient-to-r", "from-red-500", "via-yellow-500", "to-blue-500"] },
                  ].map((colorOption) => (
                    <Button
                      key={colorOption.value}
                      variant={backgroundColorVariant === colorOption.value ? "default" : "outline"}
                      className="h-auto p-2 flex flex-col items-center gap-1"
                      onClick={() => setBackgroundColorVariant(colorOption.value as any)}
                    >
                      <div className={`w-6 h-3 rounded ${colorOption.colors.join(" ")}`} />
                      <span className="text-xs">{colorOption.label}</span>
                    </Button>
                  ))}
                </div>
              </div>

              {/* Mobile scroll indicator */}
              <div className="md:hidden text-xs text-gray-500 dark:text-gray-400 text-center">
                Scroll to see all background options ↕️
              </div>
              
              <div 
                className="space-y-3 max-h-[600px] overflow-y-auto overscroll-contain scrollbar-thin md:scrollbar-thin scrollbar-hide touch-scroll relative pr-2"
                style={{
                  touchAction: 'pan-y',
                  WebkitOverflowScrolling: 'touch',
                  overscrollBehavior: 'contain',
                  scrollBehavior: 'smooth',
                  willChange: 'scroll-position',
                  // Enhanced touch scrolling
                  transform: 'translateZ(0)', // Force hardware acceleration
                  backfaceVisibility: 'hidden',
                  perspective: 1000,
                  // iOS specific improvements
                  WebkitTransform: 'translate3d(0,0,0)',
                  WebkitBackfaceVisibility: 'hidden',
                  WebkitPerspective: 1000,
                  // Momentum scrolling
                  MozOverflowScrolling: 'touch',
                  msOverflowStyle: '-ms-autohiding-scrollbar'
                }}
              >
                {backgroundOptions.map((option) => {
                  const Icon = option.icon;
                  return (
                    <div
                      key={option.value}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        background === option.value
                          ? "border-blue-500 bg-blue-50 dark:bg-blue-950"
                          : "border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600"
                      }`}
                      onClick={() => setBackground(option.value as any)}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`p-2 rounded-lg ${
                          background === option.value
                            ? "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400"
                            : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400"
                        }`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-medium text-sm">{option.label}</h4>
                            {background === option.value && (
                              <Badge className="text-xs bg-blue-500">Active</Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            {option.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Preview Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Preview</CardTitle>
              <CardDescription>
                See how your settings look
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                <div className="flex justify-between">
                  <span>Theme:</span>
                  <span className="font-medium capitalize">{theme}</span>
                </div>
                <div className="flex justify-between">
                  <span>Background:</span>
                  <span className="font-medium capitalize">{background}</span>
                </div>
                <div className="mt-4 p-3 rounded-lg bg-gray-50 dark:bg-gray-800 border">
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Changes are applied automatically and saved to your browser
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </SheetContent>
    </Sheet>
  );
}