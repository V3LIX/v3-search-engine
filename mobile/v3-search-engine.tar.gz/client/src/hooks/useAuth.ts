import { useQuery } from "@tanstack/react-query";

export function useAuth() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  // Return a mock user when not authenticated for demo purposes
  const mockUser = {
    id: "demo-user",
    email: "demo@v3lix.com",
    firstName: "Demo",
    lastName: "User",
    profileImageUrl: null,
    isAdmin: true,
  };

  return {
    user: user || mockUser,
    isLoading: false, // Always show as loaded for demo
    isAuthenticated: true, // Always authenticated for demo
  };
}
