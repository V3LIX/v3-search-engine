# V3LIX Mobile App - Google Play Store Deployment Guide

## 🚀 Complete Guide to Publishing V3LIX on Google Play Store

### Prerequisites
1. **Google Play Developer Account** ($25 one-time fee)
2. **Expo Account** (free)
3. **EAS CLI** installed globally

### Step 1: Setup Development Environment

```bash
# Install EAS CLI globally
npm install -g @expo/cli @expo/eas-cli

# Navigate to mobile directory
cd mobile

# Login to Expo
expo login

# Install dependencies
npm install
```

### Step 2: Configure App for Production

1. **Update app.json with your details:**
```json
{
  "expo": {
    "name": "V3LIX",
    "slug": "v3lix-search",
    "version": "1.0.0",
    "android": {
      "package": "com.yourdomain.v3lix"  // Change to your domain
    }
  }
}
```

2. **Create EAS project:**
```bash
eas build:configure
```

### Step 3: Build APK for Testing

```bash
# Build development APK for testing
eas build --profile preview --platform android

# Download and test the APK on your device
```

### Step 4: Build Production App Bundle

```bash
# Build production AAB for Google Play
eas build --profile production --platform android
```

### Step 5: Google Play Console Setup

1. **Create Google Play Developer Account:**
   - Go to [Google Play Console](https://play.google.com/console)
   - Pay $25 registration fee
   - Complete developer profile

2. **Create New App:**
   - Click "Create app"
   - Choose "App" and select language
   - Enter app name: "V3LIX"
   - Choose "Free" app
   - Declare content rating

3. **Upload App Bundle:**
   - Go to "Release" → "Production"
   - Click "Create new release"
   - Upload the AAB file from EAS build
   - Add release notes

### Step 6: Store Listing

1. **App Information:**
   - App name: V3LIX
   - Short description: "Private search engine for mobile"
   - Full description: 
   ```
   V3LIX is a privacy-focused search engine that protects your personal data while providing powerful search capabilities.

   Features:
   • Private web search with no tracking
   • Bookmark management
   • Search history
   • Dark/light themes
   • No data collection or sharing

   Your searches stay private and secure with V3LIX.
   ```

2. **Graphics Assets:**
   - App icon (512x512 PNG)
   - Feature graphic (1024x500 PNG)
   - Screenshots (at least 2, max 8)
   - Phone screenshots: 320-3840px width

3. **Content Rating:**
   - Complete content rating questionnaire
   - V3LIX should get "Everyone" rating

4. **Privacy Policy:**
   - Required for all apps
   - Include URL to your privacy policy

### Step 7: App Signing

```bash
# Generate upload key
keytool -genkeypair -v -keystore upload-keystore.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000

# Configure app signing in Google Play Console
```

### Step 8: Review and Release

1. **Review app details**
2. **Submit for review**
3. **Wait for approval** (usually 1-3 days)
4. **Release to production**

## 📱 Alternative: Direct APK Distribution

If you want to distribute without Google Play:

```bash
# Build standalone APK
eas build --profile preview --platform android

# Share APK file directly
# Users need to enable "Install from unknown sources"
```

## 🔄 Updates and Maintenance

For app updates:

```bash
# Update version in app.json
# Build new version
eas build --profile production --platform android

# Upload to Google Play Console
# Release update
```

## 🛠️ Domain Deployment Issue (v3lix.com)

Your web app isn't updating on v3lix.com because:

1. **Domain not connected to Replit deployment**
2. **DNS settings need configuration**
3. **Custom domain setup required**

### Fix for v3lix.com:

1. **Deploy on Replit:**
   - Click "Deploy" button in Replit
   - Choose "Autoscale Deployment"
   - Wait for deployment completion

2. **Connect Custom Domain:**
   - In deployment settings, add "v3lix.com"
   - Update DNS records at your domain registrar:
     ```
     Type: CNAME
     Name: @
     Value: [your-replit-deployment-url]
     ```

3. **Update Environment Variables:**
   - Add "v3lix.com" to REPLIT_DOMAINS
   - Restart deployment

The mobile app is completely independent and will work regardless of the web app deployment status.

## 📊 Success Metrics

After deployment, monitor:
- Download numbers
- User reviews
- Crash reports
- Performance metrics

Your V3LIX mobile app is now ready for the Google Play Store! 🎉