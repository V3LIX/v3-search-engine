import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  passwordHash: varchar("password_hash"), // For email/password authentication
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Search queries table
export const searchQueries = pgTable("search_queries", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  query: text("query").notNull(),
  filters: jsonb("filters"), // Store search filters as JSON
  resultsCount: integer("results_count").default(0),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Search results table (for caching and analytics)
export const searchResults = pgTable("search_results", {
  id: serial("id").primaryKey(),
  queryId: integer("query_id").references(() => searchQueries.id),
  title: text("title").notNull(),
  url: text("url").notNull(),
  description: text("description"),
  domain: varchar("domain"),
  contentType: varchar("content_type"),
  publishedDate: timestamp("published_date"),
  rank: integer("rank").notNull(),
  saved: boolean("saved").default(false),
  imageUrl: text("image_url"),
  thumbnailUrl: text("thumbnail_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI chat sessions
export const aiChatSessions = pgTable("ai_chat_sessions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  queryId: integer("query_id").references(() => searchQueries.id),
  messages: jsonb("messages").notNull(), // Store chat history as JSON array
  summary: text("summary"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User search history (saved/bookmarked results)
export const savedResults = pgTable("saved_results", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  resultId: integer("result_id").references(() => searchResults.id).notNull(),
  notes: text("notes"),
  tags: jsonb("tags"), // Store tags as JSON array
  createdAt: timestamp("created_at").defaultNow(),
});

// Bookmarks table for user-saved websites and links
export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  title: varchar("title").notNull(),
  url: text("url").notNull(),
  description: text("description"),
  favicon: varchar("favicon"),
  tags: text("tags").array(),
  category: varchar("category").default("General"),
  isPrivate: boolean("is_private").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  searchQueries: many(searchQueries),
  aiChatSessions: many(aiChatSessions),
  savedResults: many(savedResults),
  bookmarks: many(bookmarks),
}));

export const searchQueriesRelations = relations(searchQueries, ({ one, many }) => ({
  user: one(users, {
    fields: [searchQueries.userId],
    references: [users.id],
  }),
  results: many(searchResults),
  aiChatSessions: many(aiChatSessions),
}));

export const searchResultsRelations = relations(searchResults, ({ one, many }) => ({
  query: one(searchQueries, {
    fields: [searchResults.queryId],
    references: [searchQueries.id],
  }),
  savedResults: many(savedResults),
}));

export const aiChatSessionsRelations = relations(aiChatSessions, ({ one }) => ({
  user: one(users, {
    fields: [aiChatSessions.userId],
    references: [users.id],
  }),
  query: one(searchQueries, {
    fields: [aiChatSessions.queryId],
    references: [searchQueries.id],
  }),
}));

export const savedResultsRelations = relations(savedResults, ({ one }) => ({
  user: one(users, {
    fields: [savedResults.userId],
    references: [users.id],
  }),
  result: one(searchResults, {
    fields: [savedResults.resultId],
    references: [searchResults.id],
  }),
}));

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  user: one(users, {
    fields: [bookmarks.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertSearchQuerySchema = createInsertSchema(searchQueries).omit({
  id: true,
  timestamp: true,
});

export const insertSearchResultSchema = createInsertSchema(searchResults).omit({
  id: true,
  createdAt: true,
});

export const insertAiChatSessionSchema = createInsertSchema(aiChatSessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSavedResultSchema = createInsertSchema(savedResults).omit({
  id: true,
  createdAt: true,
});

export const insertBookmarkSchema = createInsertSchema(bookmarks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertSearchQuery = z.infer<typeof insertSearchQuerySchema>;
export type SearchQuery = typeof searchQueries.$inferSelect;
export type InsertSearchResult = z.infer<typeof insertSearchResultSchema>;
export type SearchResult = typeof searchResults.$inferSelect;
export type InsertAiChatSession = z.infer<typeof insertAiChatSessionSchema>;
export type AiChatSession = typeof aiChatSessions.$inferSelect;
export type InsertSavedResult = z.infer<typeof insertSavedResultSchema>;
export type SavedResult = typeof savedResults.$inferSelect;
export type InsertBookmark = z.infer<typeof insertBookmarkSchema>;
export type Bookmark = typeof bookmarks.$inferSelect;
