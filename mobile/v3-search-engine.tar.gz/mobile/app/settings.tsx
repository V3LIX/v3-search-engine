import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Link } from 'expo-router';

export default function SettingsScreen() {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [privateMode, setPrivateMode] = useState(true);
  const [autoBookmark, setAutoBookmark] = useState(false);

  const showAlert = (title: string, message: string) => {
    Alert.alert(title, message);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        {/* Profile Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Profile</Text>
          <TouchableOpacity 
            style={styles.profileCard}
            onPress={() => showAlert('Profile', 'Profile management coming soon')}
          >
            <View style={styles.avatar}>
              <Ionicons name="person" size={24} color="#fff" />
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>Demo User</Text>
              <Text style={styles.profileEmail}>demo@v3lix.com</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#6b7280" />
          </TouchableOpacity>
        </View>

        {/* Privacy Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Privacy & Security</Text>
          
          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Ionicons name="shield-checkmark" size={20} color="#10B981" style={styles.settingIcon} />
              <View>
                <Text style={styles.settingTitle}>Private Mode</Text>
                <Text style={styles.settingSubtitle}>All searches are private and encrypted</Text>
              </View>
            </View>
            <Switch
              value={privateMode}
              onValueChange={setPrivateMode}
              trackColor={{ false: '#f3f4f6', true: '#3B82F6' }}
            />
          </View>

          <TouchableOpacity 
            style={styles.settingCard}
            onPress={() => showAlert('Clear Data', 'This will clear all your search history and bookmarks. This action cannot be undone.')}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="trash" size={20} color="#EF4444" style={styles.settingIcon} />
              <View>
                <Text style={[styles.settingTitle, { color: '#EF4444' }]}>Clear All Data</Text>
                <Text style={styles.settingSubtitle}>Remove all searches and bookmarks</Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#6b7280" />
          </TouchableOpacity>
        </View>

        {/* App Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>App Settings</Text>
          
          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Ionicons name="moon" size={20} color="#8B5CF6" style={styles.settingIcon} />
              <View>
                <Text style={styles.settingTitle}>Dark Mode</Text>
                <Text style={styles.settingSubtitle}>Use dark theme</Text>
              </View>
            </View>
            <Switch
              value={darkMode}
              onValueChange={setDarkMode}
              trackColor={{ false: '#f3f4f6', true: '#3B82F6' }}
            />
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Ionicons name="notifications" size={20} color="#F59E0B" style={styles.settingIcon} />
              <View>
                <Text style={styles.settingTitle}>Notifications</Text>
                <Text style={styles.settingSubtitle}>Get updates and alerts</Text>
              </View>
            </View>
            <Switch
              value={notifications}
              onValueChange={setNotifications}
              trackColor={{ false: '#f3f4f6', true: '#3B82F6' }}
            />
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Ionicons name="bookmark" size={20} color="#3B82F6" style={styles.settingIcon} />
              <View>
                <Text style={styles.settingTitle}>Auto-Bookmark</Text>
                <Text style={styles.settingSubtitle}>Automatically save search results</Text>
              </View>
            </View>
            <Switch
              value={autoBookmark}
              onValueChange={setAutoBookmark}
              trackColor={{ false: '#f3f4f6', true: '#3B82F6' }}
            />
          </View>
        </View>

        {/* About Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          
          <TouchableOpacity 
            style={styles.settingCard}
            onPress={() => showAlert('About V3LIX', 'V3LIX v1.0.0\nPrivate search engine for mobile\n\nBuilt with privacy in mind.')}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="information-circle" size={20} color="#6b7280" style={styles.settingIcon} />
              <View>
                <Text style={styles.settingTitle}>About V3LIX</Text>
                <Text style={styles.settingSubtitle}>Version 1.0.0</Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#6b7280" />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.settingCard}
            onPress={() => showAlert('Privacy Policy', 'Your privacy is our priority. V3LIX does not collect, store, or share your personal data.')}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="document-text" size={20} color="#6b7280" style={styles.settingIcon} />
              <View>
                <Text style={styles.settingTitle}>Privacy Policy</Text>
                <Text style={styles.settingSubtitle}>How we protect your data</Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#6b7280" />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.settingCard}
            onPress={() => showAlert('Support', 'Need help? Contact us at support@v3lix.com')}
          >
            <View style={styles.settingInfo}>
              <Ionicons name="help-circle" size={20} color="#6b7280" style={styles.settingIcon} />
              <View>
                <Text style={styles.settingTitle}>Help & Support</Text>
                <Text style={styles.settingSubtitle}>Get help and contact us</Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#6b7280" />
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Bottom Navigation */}
      <View style={styles.bottomNav}>
        <Link href="/" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="search" size={24} color="#666" />
            <Text style={styles.navText}>Search</Text>
          </TouchableOpacity>
        </Link>
        
        <Link href="/bookmarks" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="bookmark" size={24} color="#666" />
            <Text style={styles.navText}>Bookmarks</Text>
          </TouchableOpacity>
        </Link>
        
        <Link href="/history" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="time" size={24} color="#666" />
            <Text style={styles.navText}>History</Text>
          </TouchableOpacity>
        </Link>
        
        <TouchableOpacity style={[styles.navItem, styles.navItemActive]}>
          <Ionicons name="settings" size={24} color="#3B82F6" />
          <Text style={[styles.navText, styles.navTextActive]}>Settings</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  content: {
    flex: 1,
    paddingBottom: 80,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 12,
    marginHorizontal: 20,
  },
  profileCard: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  avatar: {
    width: 48,
    height: 48,
    backgroundColor: '#3B82F6',
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
  },
  profileEmail: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 2,
  },
  settingCard: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    marginBottom: 8,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    marginRight: 16,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1f2937',
  },
  settingSubtitle: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 2,
  },
  bottomNav: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
  },
  navItemActive: {
    backgroundColor: '#eff6ff',
    borderRadius: 8,
  },
  navText: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  navTextActive: {
    color: '#3B82F6',
    fontWeight: '600',
  },
});