import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Link } from 'expo-router';

interface Bookmark {
  id: number;
  title: string;
  url: string;
  description: string;
  category: string;
}

export default function BookmarksScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarks] = useState<Bookmark[]>([
    {
      id: 1,
      title: 'React Native Documentation',
      url: 'https://reactnative.dev',
      description: 'Learn React Native development',
      category: 'Development',
    },
    {
      id: 2,
      title: 'Expo Documentation',
      url: 'https://docs.expo.dev',
      description: 'Build universal native apps',
      category: 'Development',
    },
    {
      id: 3,
      title: 'Privacy Tools',
      url: 'https://privacytools.io',
      description: 'Tools for digital privacy',
      category: 'Privacy',
    },
  ]);

  const filteredBookmarks = bookmarks.filter(bookmark =>
    bookmark.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openBookmark = (url: string) => {
    Alert.alert(
      'Open Bookmark',
      `Would you like to open: ${url}`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Open', onPress: () => console.log('Opening:', url) },
      ]
    );
  };

  const deleteBookmark = (id: number) => {
    Alert.alert(
      'Delete Bookmark',
      'Are you sure you want to delete this bookmark?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => console.log('Deleted:', id) },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <Ionicons name="search" size={20} color="#666" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search bookmarks..."
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </View>

        {/* Bookmarks List */}
        <View style={styles.bookmarksList}>
          {filteredBookmarks.map((bookmark) => (
            <View key={bookmark.id} style={styles.bookmarkCard}>
              <TouchableOpacity
                style={styles.bookmarkContent}
                onPress={() => openBookmark(bookmark.url)}
              >
                <Text style={styles.bookmarkTitle}>{bookmark.title}</Text>
                <Text style={styles.bookmarkUrl}>{bookmark.url}</Text>
                <Text style={styles.bookmarkDescription}>{bookmark.description}</Text>
                <View style={styles.bookmarkMeta}>
                  <View style={styles.categoryBadge}>
                    <Text style={styles.categoryText}>{bookmark.category}</Text>
                  </View>
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => deleteBookmark(bookmark.id)}
              >
                <Ionicons name="trash" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          ))}
        </View>

        {filteredBookmarks.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="bookmark" size={64} color="#ccc" />
            <Text style={styles.emptyStateTitle}>No Bookmarks Found</Text>
            <Text style={styles.emptyStateText}>
              {searchQuery ? 'Try adjusting your search' : 'Your saved bookmarks will appear here'}
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Bottom Navigation */}
      <View style={styles.bottomNav}>
        <Link href="/" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="search" size={24} color="#666" />
            <Text style={styles.navText}>Search</Text>
          </TouchableOpacity>
        </Link>
        
        <TouchableOpacity style={[styles.navItem, styles.navItemActive]}>
          <Ionicons name="bookmark" size={24} color="#3B82F6" />
          <Text style={[styles.navText, styles.navTextActive]}>Bookmarks</Text>
        </TouchableOpacity>
        
        <Link href="/history" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="time" size={24} color="#666" />
            <Text style={styles.navText}>History</Text>
          </TouchableOpacity>
        </Link>
        
        <Link href="/settings" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="settings" size={24} color="#666" />
            <Text style={styles.navText}>Settings</Text>
          </TouchableOpacity>
        </Link>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  content: {
    flex: 1,
    paddingBottom: 80,
  },
  searchContainer: {
    padding: 20,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
  },
  bookmarksList: {
    padding: 20,
    paddingTop: 0,
  },
  bookmarkCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    flexDirection: 'row',
    alignItems: 'center',
  },
  bookmarkContent: {
    flex: 1,
    padding: 16,
  },
  bookmarkTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  bookmarkUrl: {
    fontSize: 14,
    color: '#10B981',
    marginBottom: 8,
  },
  bookmarkDescription: {
    fontSize: 14,
    color: '#6b7280',
    lineHeight: 20,
    marginBottom: 12,
  },
  bookmarkMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryBadge: {
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoryText: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '500',
  },
  deleteButton: {
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
    marginTop: 60,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1f2937',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  bottomNav: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
  },
  navItemActive: {
    backgroundColor: '#eff6ff',
    borderRadius: 8,
  },
  navText: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  navTextActive: {
    color: '#3B82F6',
    fontWeight: '600',
  },
});