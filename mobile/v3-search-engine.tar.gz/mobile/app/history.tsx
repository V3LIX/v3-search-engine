import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Link } from 'expo-router';

interface SearchQuery {
  id: number;
  query: string;
  timestamp: string;
  resultsCount: number;
}

export default function HistoryScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchHistory] = useState<SearchQuery[]>([
    {
      id: 1,
      query: 'React Native best practices',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      resultsCount: 15,
    },
    {
      id: 2,
      query: 'Mobile app privacy tools',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      resultsCount: 22,
    },
    {
      id: 3,
      query: 'Expo development guide',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      resultsCount: 8,
    },
  ]);

  const filteredHistory = searchHistory.filter(item =>
    item.query.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  const searchAgain = (query: string) => {
    console.log('Searching again for:', query);
    // Navigate back to search with this query
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <Ionicons name="search" size={20} color="#666" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search your history..."
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Ionicons name="search" size={24} color="#3B82F6" />
            <Text style={styles.statNumber}>{searchHistory.length}</Text>
            <Text style={styles.statLabel}>Total Searches</Text>
          </View>
          
          <View style={styles.statCard}>
            <Ionicons name="trending-up" size={24} color="#10B981" />
            <Text style={styles.statNumber}>
              {searchHistory.filter(q => {
                const weekAgo = new Date();
                weekAgo.setDate(weekAgo.getDate() - 7);
                return new Date(q.timestamp) > weekAgo;
              }).length}
            </Text>
            <Text style={styles.statLabel}>This Week</Text>
          </View>
          
          <View style={styles.statCard}>
            <Ionicons name="calendar" size={24} color="#8B5CF6" />
            <Text style={styles.statNumber}>
              {searchHistory.filter(q => {
                const today = new Date();
                const queryDate = new Date(q.timestamp);
                return queryDate.toDateString() === today.toDateString();
              }).length}
            </Text>
            <Text style={styles.statLabel}>Today</Text>
          </View>
        </View>

        {/* History List */}
        <View style={styles.historyList}>
          {filteredHistory.map((item) => (
            <View key={item.id} style={styles.historyCard}>
              <View style={styles.historyContent}>
                <Text style={styles.historyQuery}>{item.query}</Text>
                <View style={styles.historyMeta}>
                  <View style={styles.metaItem}>
                    <Ionicons name="time" size={14} color="#6b7280" />
                    <Text style={styles.metaText}>{formatTimeAgo(item.timestamp)}</Text>
                  </View>
                  <View style={styles.resultsBadge}>
                    <Text style={styles.resultsText}>{item.resultsCount} results</Text>
                  </View>
                </View>
              </View>
              
              <TouchableOpacity
                style={styles.searchAgainButton}
                onPress={() => searchAgain(item.query)}
              >
                <Text style={styles.searchAgainText}>Search Again</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>

        {filteredHistory.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="time" size={64} color="#ccc" />
            <Text style={styles.emptyStateTitle}>No Search History</Text>
            <Text style={styles.emptyStateText}>
              {searchQuery ? 'No matching searches found' : 'Your search history will appear here'}
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Bottom Navigation */}
      <View style={styles.bottomNav}>
        <Link href="/" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="search" size={24} color="#666" />
            <Text style={styles.navText}>Search</Text>
          </TouchableOpacity>
        </Link>
        
        <Link href="/bookmarks" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="bookmark" size={24} color="#666" />
            <Text style={styles.navText}>Bookmarks</Text>
          </TouchableOpacity>
        </Link>
        
        <TouchableOpacity style={[styles.navItem, styles.navItemActive]}>
          <Ionicons name="time" size={24} color="#3B82F6" />
          <Text style={[styles.navText, styles.navTextActive]}>History</Text>
        </TouchableOpacity>
        
        <Link href="/settings" asChild>
          <TouchableOpacity style={styles.navItem}>
            <Ionicons name="settings" size={24} color="#666" />
            <Text style={styles.navText}>Settings</Text>
          </TouchableOpacity>
        </Link>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  content: {
    flex: 1,
    paddingBottom: 80,
  },
  searchContainer: {
    padding: 20,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingBottom: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
    textAlign: 'center',
  },
  historyList: {
    padding: 20,
    paddingTop: 0,
  },
  historyCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    flexDirection: 'row',
    alignItems: 'center',
  },
  historyContent: {
    flex: 1,
    padding: 16,
  },
  historyQuery: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 8,
  },
  historyMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    color: '#6b7280',
  },
  resultsBadge: {
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  resultsText: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '500',
  },
  searchAgainButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 16,
    backgroundColor: '#3B82F6',
    borderRadius: 8,
  },
  searchAgainText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
    marginTop: 60,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1f2937',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  bottomNav: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
  },
  navItemActive: {
    backgroundColor: '#eff6ff',
    borderRadius: 8,
  },
  navText: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  navTextActive: {
    color: '#3B82F6',
    fontWeight: '600',
  },
});