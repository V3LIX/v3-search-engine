import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <Stack
        screenOptions={{
          headerStyle: {
            backgroundColor: '#3B82F6',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        <Stack.Screen 
          name="index" 
          options={{ 
            title: 'V3LIX Search',
            headerShown: true
          }} 
        />
        <Stack.Screen 
          name="bookmarks" 
          options={{ 
            title: 'Bookmarks',
            headerShown: true
          }} 
        />
        <Stack.Screen 
          name="history" 
          options={{ 
            title: 'Search History',
            headerShown: true
          }} 
        />
        <Stack.Screen 
          name="settings" 
          options={{ 
            title: 'Settings',
            headerShown: true
          }} 
        />
      </Stack>
      <StatusBar style="light" />
    </SafeAreaProvider>
  );
}