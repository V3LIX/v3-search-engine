import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertSearchQuerySchema, insertAiChatSessionSchema } from "@shared/schema";
import { z } from "zod";

// Mock search function (replace with real search engine later)
async function performSearch(query: string, filters: any = {}) {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Generate different results based on search category
  const category = filters.category || 'all';
  let mockResults = [];
  
  switch (category) {
    case 'images':
      // Generate image results with real Unsplash URLs based on the search query
      const searchKeywords = query.replace(/\s+/g, '+').toLowerCase();
      const imageVariations = [
        { w: 800, h: 600, seed: 1 },
        { w: 800, h: 600, seed: 2 },
        { w: 800, h: 600, seed: 3 },
        { w: 800, h: 600, seed: 4 },
        { w: 800, h: 600, seed: 5 },
        { w: 800, h: 600, seed: 6 }
      ];
      
      mockResults = imageVariations.map((img, index) => {
        const unsplashUrl = `https://source.unsplash.com/${img.w}x${img.h}/?${searchKeywords}&sig=${img.seed}`;
        const thumbnailUrl = `https://source.unsplash.com/300x200/?${searchKeywords}&sig=${img.seed}`;
        
        return {
          title: `${query} - ${['High Resolution Photo', 'Professional Photography', 'Creative Collection', 'Artistic Vision', 'Modern Perspective', 'Design Elements'][index]}`,
          url: unsplashUrl,
          imageUrl: unsplashUrl,
          thumbnailUrl: thumbnailUrl,
          description: `${['High-quality photo', 'Professional photography', 'Creative visual content', 'Artistic representation', 'Modern visual perspective', 'Design elements inspired'][index]} related to ${query}`,
          domain: "unsplash.com",
          contentType: "image",
          publishedDate: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
          rank: index + 1,
        };
      });
      break;
    case 'videos':
      mockResults = [
        {
          title: `${query} Tutorial Series`,
          url: `https://videos.learn.com/${query.replace(/\s+/g, '-').toLowerCase()}`,
          description: `Complete video guide about ${query} - Educational content`,
          domain: "videos.learn.com",
          contentType: "video",
          publishedDate: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
          rank: 1,
        },
        {
          title: `${query} Explained`,
          url: `https://tech-videos.org/${query.replace(/\s+/g, '-').toLowerCase()}`,
          description: `Expert explanation of ${query} concepts`,
          domain: "tech-videos.org",
          contentType: "video",
          publishedDate: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
          rank: 2,
        }
      ];
      break;
    case 'shorts':
      mockResults = [
        {
          title: `${query} Quick Tips`,
          url: `https://shorts.dev/${query.replace(/\s+/g, '-').toLowerCase()}`,
          description: `Quick tips about ${query} in 60 seconds`,
          domain: "shorts.dev",
          contentType: "short_video",
          publishedDate: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
          rank: 1,
        },
        {
          title: `${query} in 30 Seconds`,
          url: `https://quickguides.com/${query.replace(/\s+/g, '-').toLowerCase()}`,
          description: `Learn ${query} basics in under 30 seconds`,
          domain: "quickguides.com",
          contentType: "short_video",
          publishedDate: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
          rank: 2,
        }
      ];
      break;
    case 'news':
      mockResults = [
        {
          title: `Latest ${query} News Today`,
          url: `https://technews.com/${query.replace(/\s+/g, '-').toLowerCase()}-update`,
          description: `Breaking news and updates about ${query}`,
          domain: "technews.com",
          contentType: "news",
          publishedDate: new Date(Date.now() - Math.random() * 1 * 24 * 60 * 60 * 1000),
          rank: 1,
        },
        {
          title: `${query} Industry Report`,
          url: `https://industry-news.org/${query.replace(/\s+/g, '-').toLowerCase()}`,
          description: `Industry analysis and trends for ${query}`,
          domain: "industry-news.org",
          contentType: "news",
          publishedDate: new Date(Date.now() - Math.random() * 2 * 24 * 60 * 60 * 1000),
          rank: 2,
        }
      ];
      break;
    case 'maps':
      mockResults = [
        {
          title: `${query} Locations Near You`,
          url: `https://maps.service.com/${query.replace(/\s+/g, '-').toLowerCase()}`,
          description: `Find ${query} locations and services nearby`,
          domain: "maps.service.com",
          contentType: "map",
          publishedDate: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
          rank: 1,
        },
        {
          title: `${query} Directory`,
          url: `https://location-finder.com/${query.replace(/\s+/g, '-').toLowerCase()}`,
          description: `Complete directory of ${query} places and venues`,
          domain: "location-finder.com",
          contentType: "map",
          publishedDate: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
          rank: 2,
        }
      ];
      break;
    default:
      // Generate varied search results based on the actual query
      const queryWords = query.toLowerCase().split(' ');
      const searchTerms = query.replace(/\s+/g, '-').toLowerCase();
      
      // Create different types of results based on query content
      const resultTypes = [
        {
          type: 'guide',
          titles: [`Understanding ${query}: A Comprehensive Guide`, `Complete Guide to ${query}`, `${query} Explained: Everything You Need to Know`],
          domains: ['guide.com', 'learn-online.org', 'comprehensive-guides.net'],
          descriptions: [
            `This comprehensive guide explores the topic of ${query} in detail, providing insights and practical information.`,
            `Everything you need to know about ${query}, from basics to advanced concepts.`,
            `Detailed explanation of ${query} with step-by-step instructions and examples.`
          ]
        },
        {
          type: 'tips',
          titles: [`${query} Best Practices and Tips`, `Top 10 Tips for ${query}`, `Expert ${query} Strategies`],
          domains: ['techblog.com', 'pro-tips.org', 'expert-advice.net'],
          descriptions: [
            `Discover the best practices and expert tips for ${query}. Common pitfalls and advanced techniques.`,
            `Professional strategies and techniques for mastering ${query}.`,
            `Industry experts share their top tips and tricks for ${query}.`
          ]
        },
        {
          type: 'research',
          titles: [`Research Paper: ${query} Analysis`, `Latest Research on ${query}`, `${query}: Academic Perspective`],
          domains: ['research.university.edu', 'academic-journal.org', 'scientific-studies.com'],
          descriptions: [
            `Academic research analyzing various aspects of ${query}, including methodologies and findings.`,
            `Latest scientific research and developments in ${query}.`,
            `Peer-reviewed academic analysis of ${query} trends and implications.`
          ]
        },
        {
          type: 'news',
          titles: [`Breaking: ${query} Updates`, `Latest ${query} News`, `${query} in the Headlines`],
          domains: ['news-today.com', 'current-events.org', 'breaking-news.net'],
          descriptions: [
            `Latest news and updates about ${query} from around the world.`,
            `Current events and developments related to ${query}.`,
            `Breaking news and trending topics about ${query}.`
          ]
        },
        {
          type: 'tutorial',
          titles: [`How to ${query}: Step by Step`, `${query} Tutorial for Beginners`, `Learn ${query} Fast`],
          domains: ['tutorials.com', 'how-to-guide.org', 'learning-hub.net'],
          descriptions: [
            `Step-by-step tutorial on how to get started with ${query}.`,
            `Beginner-friendly guide to learning ${query} quickly and effectively.`,
            `Practical tutorial with hands-on examples for ${query}.`
          ]
        }
      ];
      
      mockResults = resultTypes.slice(0, 3 + Math.floor(Math.random() * 3)).map((resultType, index) => {
        const titleIndex = Math.floor(Math.random() * resultType.titles.length);
        const domainIndex = Math.floor(Math.random() * resultType.domains.length);
        const descIndex = Math.floor(Math.random() * resultType.descriptions.length);
        
        return {
          title: resultType.titles[titleIndex],
          url: `https://${resultType.domains[domainIndex]}/${resultType.type}/${searchTerms}`,
          description: resultType.descriptions[descIndex],
          domain: resultType.domains[domainIndex],
          contentType: resultType.type === 'research' ? 'pdf' : resultType.type === 'news' ? 'news' : 'article',
          publishedDate: new Date(Date.now() - Math.random() * (resultType.type === 'news' ? 7 : resultType.type === 'research' ? 90 : 30) * 24 * 60 * 60 * 1000),
          rank: index + 1,
        };
      });
  }

  return mockResults;
}

// Mock AI response function (replace with real AI integration later)
async function generateAIResponse(message: string, context: any = {}) {
  // Simulate AI processing delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

  const responses = [
    `Based on the search results about "${context.query || 'your question'}", I can provide some insights. ${message.includes('privacy') ? 'Privacy is indeed a crucial consideration in modern search technology.' : ''} ${message.includes('AI') ? 'AI technology is rapidly evolving and has significant implications for search and information retrieval.' : ''} Would you like me to elaborate on any specific aspect?`,
    
    `That's an interesting question about ${context.query || 'the topic'}. From the available information, it appears that ${message.includes('how') ? 'the process involves several key steps and considerations' : 'there are multiple perspectives to consider'}. ${message.includes('benefits') ? 'The main benefits include improved efficiency and better user experience.' : ''} Is there a particular aspect you'd like to explore further?`,
    
    `I've analyzed the search results and can help clarify this topic. ${message.includes('difference') ? 'The key differences lie in the approach and implementation details.' : ''} ${message.includes('best') ? 'The best practices generally focus on security, privacy, and user experience.' : ''} Feel free to ask for more specific information about any particular point.`,
  ];

  return responses[Math.floor(Math.random() * responses.length)];
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Email authentication routes
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      
      // Find user by email
      const user = await storage.getUserByEmail(email);
      if (!user || !user.passwordHash) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Verify password hash
      const bcrypt = require('bcrypt');
      const isValidPassword = await bcrypt.compare(password, user.passwordHash);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Create session
      req.session.user = {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
      };
      
      res.json({ message: "Login successful", user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
      }});
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/auth/signup', async (req, res) => {
    try {
      const { firstName, lastName, email, password } = req.body;
      
      // Validate input
      if (!firstName || !lastName || !email || !password) {
        return res.status(400).json({ message: "All fields are required" });
      }

      if (password.length < 8) {
        return res.status(400).json({ message: "Password must be at least 8 characters long" });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "An account with this email already exists" });
      }
      
      // Hash the password
      const bcrypt = require('bcrypt');
      const passwordHash = await bcrypt.hash(password, 12);
      
      // Create new user
      const newUser = await storage.createEmailUser({
        email,
        firstName,
        lastName,
        passwordHash,
      });
      
      res.json({ message: "Account created successfully! Please sign in with your new account.", user: {
        id: newUser.id,
        email: newUser.email,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
      }});
    } catch (error) {
      console.error("Signup error:", error);
      res.status(500).json({ message: "Failed to create account. Please try again." });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({ message: 'Failed to logout' });
      }
      res.clearCookie('connect.sid');
      res.json({ message: 'Logout successful' });
    });
  });

  // Social auth routes
  app.get('/api/auth/google', (req, res) => {
    if (!process.env.GOOGLE_CLIENT_ID) {
      return res.status(500).json({ error: 'Google OAuth not configured' });
    }
    const googleAuthUrl = `https://accounts.google.com/oauth/authorize?client_id=${process.env.GOOGLE_CLIENT_ID}&redirect_uri=${req.protocol}://${req.hostname}/api/auth/google/callback&response_type=code&scope=email profile openid`;
    res.redirect(googleAuthUrl);
  });

  app.get('/api/auth/microsoft', (req, res) => {
    if (!process.env.MICROSOFT_CLIENT_ID) {
      return res.status(500).json({ error: 'Microsoft OAuth not configured' });
    }
    const microsoftAuthUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=${process.env.MICROSOFT_CLIENT_ID}&redirect_uri=${req.protocol}://${req.hostname}/api/auth/microsoft/callback&response_type=code&scope=openid profile email`;
    res.redirect(microsoftAuthUrl);
  });



  // OAuth callback handlers
  app.get('/api/auth/google/callback', async (req, res) => {
    try {
      const { code } = req.query;
      if (!code) {
        return res.status(400).json({ error: 'No authorization code received' });
      }

      // Exchange code for access token
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: process.env.GOOGLE_CLIENT_ID!,
          client_secret: process.env.GOOGLE_CLIENT_SECRET!,
          code: code as string,
          grant_type: 'authorization_code',
          redirect_uri: `${req.protocol}://${req.hostname}/api/auth/google/callback`
        })
      });

      const tokenData = await tokenResponse.json();
      
      // Get user info from Google
      const userResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });
      
      const userData = await userResponse.json();
      
      // Create or update user in database
      const user = await storage.upsertUser({
        id: userData.id,
        email: userData.email,
        firstName: userData.given_name,
        lastName: userData.family_name,
        profileImageUrl: userData.picture,
      });

      // Create session
      req.session.user = user;
      res.redirect('/');
    } catch (error) {
      console.error('Google OAuth error:', error);
      res.status(500).json({ error: 'Authentication failed' });
    }
  });

  app.get('/api/auth/microsoft/callback', async (req, res) => {
    try {
      const { code } = req.query;
      if (!code) {
        return res.status(400).json({ error: 'No authorization code received' });
      }

      // Exchange code for access token
      const tokenResponse = await fetch('https://login.microsoftonline.com/common/oauth2/v2.0/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: process.env.MICROSOFT_CLIENT_ID!,
          client_secret: process.env.MICROSOFT_CLIENT_SECRET!,
          code: code as string,
          grant_type: 'authorization_code',
          redirect_uri: `${req.protocol}://${req.hostname}/api/auth/microsoft/callback`
        })
      });

      const tokenData = await tokenResponse.json();
      
      // Get user info from Microsoft
      const userResponse = await fetch('https://graph.microsoft.com/v1.0/me', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });
      
      const userData = await userResponse.json();
      
      // Create or update user in database
      const user = await storage.upsertUser({
        id: userData.id,
        email: userData.mail || userData.userPrincipalName,
        firstName: userData.givenName,
        lastName: userData.surname,
        profileImageUrl: null,
      });

      // Create session
      req.session.user = user;
      res.redirect('/');
    } catch (error) {
      console.error('Microsoft OAuth error:', error);
      res.status(500).json({ error: 'Authentication failed' });
    }
  });



  // Search routes
  app.post('/api/search', isAuthenticated, async (req: any, res) => {
    try {
      const { query, filters = {} } = req.body;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }

      const userId = req.user.claims.sub;

      // Create search query record
      const searchQuery = await storage.createSearchQuery({
        userId,
        query: query.trim(),
        filters,
      });

      // Perform search (currently mock data)
      const searchResults = await performSearch(query, filters);

      // Store search results
      const resultsWithQueryId = searchResults.map((result, index) => ({
        ...result,
        queryId: searchQuery.id,
        rank: index + 1,
      }));

      const storedResults = await storage.createSearchResults(resultsWithQueryId);

      // Results count is already set during creation, no need to update

      res.json({
        searchQuery,
        results: storedResults,
        stats: {
          total: storedResults.length,
          duration: Math.random() * 0.5 + 0.1, // Mock duration
        },
      });

    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Get search results
  app.get('/api/search/:queryId/results', isAuthenticated, async (req, res) => {
    try {
      const queryId = parseInt(req.params.queryId);
      const results = await storage.getSearchResults(queryId);
      res.json(results);
    } catch (error) {
      console.error("Error fetching search results:", error);
      res.status(500).json({ message: "Failed to fetch search results" });
    }
  });

  // Search history
  app.get('/api/search/history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 50;
      const history = await storage.getSearchHistory(userId, limit);
      res.json(history);
    } catch (error) {
      console.error("Error fetching search history:", error);
      res.status(500).json({ message: "Failed to fetch search history" });
    }
  });

  // Save/unsave result
  app.post('/api/results/:resultId/save', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resultId = parseInt(req.params.resultId);
      
      const saved = await storage.toggleSavedResult(userId, resultId);
      res.json({ saved: !!saved });
    } catch (error) {
      console.error("Error toggling saved result:", error);
      res.status(500).json({ message: "Failed to save/unsave result" });
    }
  });

  // Get saved results
  app.get('/api/results/saved', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const savedResults = await storage.getSavedResults(userId);
      res.json(savedResults);
    } catch (error) {
      console.error("Error fetching saved results:", error);
      res.status(500).json({ message: "Failed to fetch saved results" });
    }
  });

  // AI Chat routes
  app.post('/api/ai/chat', isAuthenticated, async (req: any, res) => {
    try {
      const { message, queryId, sessionId } = req.body;
      const userId = req.user.claims.sub;

      if (!message || typeof message !== 'string') {
        return res.status(400).json({ message: "Message is required" });
      }

      let chatSession;
      
      if (sessionId) {
        // Get existing session
        chatSession = await storage.getAiChatSession(queryId);
        if (!chatSession) {
          return res.status(404).json({ message: "Chat session not found" });
        }
      } else {
        // Create new session
        chatSession = await storage.createAiChatSession({
          userId,
          queryId: queryId || null,
          messages: [],
        });
      }

      // Get context for AI
      let context: any = {};
      if (queryId) {
        const query = await storage.getSearchQuery(queryId);
        if (query) {
          context.query = query.query;
          context.results = await storage.getSearchResults(queryId);
        }
      }

      // Generate AI response
      const aiResponse = await generateAIResponse(message, context);

      // Update chat session with new messages
      const currentMessages = Array.isArray(chatSession.messages) ? chatSession.messages : [];
      const updatedMessages = [
        ...currentMessages,
        { role: 'user', content: message, timestamp: new Date().toISOString() },
        { role: 'assistant', content: aiResponse, timestamp: new Date().toISOString() },
      ];

      const updatedSession = await storage.updateAiChatSession(chatSession.id, {
        messages: updatedMessages,
      });

      res.json({
        response: aiResponse,
        sessionId: updatedSession.id,
        messages: updatedMessages,
      });

    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ message: "AI chat failed" });
    }
  });

  // Get AI chat session
  app.get('/api/ai/chat/:queryId', isAuthenticated, async (req, res) => {
    try {
      const queryId = parseInt(req.params.queryId);
      const session = await storage.getAiChatSession(queryId);
      res.json(session);
    } catch (error) {
      console.error("Error fetching AI chat session:", error);
      res.status(500).json({ message: "Failed to fetch chat session" });
    }
  });

  // Bookmarks routes
  app.get("/api/bookmarks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { category } = req.query;
      const bookmarks = await storage.getBookmarks(userId, category);
      res.json(bookmarks);
    } catch (error) {
      console.error("Error fetching bookmarks:", error);
      res.status(500).json({ message: "Failed to fetch bookmarks" });
    }
  });

  app.post("/api/bookmarks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookmarkData = { ...req.body, userId };
      const bookmark = await storage.createBookmark(bookmarkData);
      res.status(201).json(bookmark);
    } catch (error) {
      console.error("Error creating bookmark:", error);
      res.status(500).json({ message: "Failed to create bookmark" });
    }
  });

  app.put("/api/bookmarks/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const bookmark = await storage.updateBookmark(parseInt(id), updates);
      res.json(bookmark);
    } catch (error) {
      console.error("Error updating bookmark:", error);
      res.status(500).json({ message: "Failed to update bookmark" });
    }
  });

  app.delete("/api/bookmarks/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const success = await storage.deleteBookmark(parseInt(id), userId);
      if (success) {
        res.json({ message: "Bookmark deleted successfully" });
      } else {
        res.status(404).json({ message: "Bookmark not found" });
      }
    } catch (error) {
      console.error("Error deleting bookmark:", error);
      res.status(500).json({ message: "Failed to delete bookmark" });
    }
  });

  app.get("/api/bookmarks/categories", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const categories = await storage.getBookmarkCategories(userId);
      res.json(categories);
    } catch (error) {
      console.error("Error fetching bookmark categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Admin routes (protected)
  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getSearchStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get('/api/admin/popular-searches', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const limit = parseInt(req.query.limit as string) || 10;
      const popularSearches = await storage.getPopularSearches(limit);
      res.json(popularSearches);
    } catch (error) {
      console.error("Error fetching popular searches:", error);
      res.status(500).json({ message: "Failed to fetch popular searches" });
    }
  });

  app.get('/api/admin/recent-searches', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const limit = parseInt(req.query.limit as string) || 20;
      const recentSearches = await storage.getRecentSearches(limit);
      res.json(recentSearches);
    } catch (error) {
      console.error("Error fetching recent searches:", error);
      res.status(500).json({ message: "Failed to fetch recent searches" });
    }
  });

  // Admin actions
  app.post('/api/admin/reindex', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Mock reindex operation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      res.json({ message: "Reindex completed successfully" });
    } catch (error) {
      console.error("Error during reindex:", error);
      res.status(500).json({ message: "Reindex failed" });
    }
  });

  app.post('/api/admin/clear-cache', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Mock cache clear operation
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      res.json({ message: "Cache cleared successfully" });
    } catch (error) {
      console.error("Error clearing cache:", error);
      res.status(500).json({ message: "Cache clear failed" });
    }
  });

  // Bookmarks routes
  app.get('/api/bookmarks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const category = req.query.category as string;
      const bookmarks = await storage.getBookmarks(userId, category);
      res.json(bookmarks);
    } catch (error) {
      console.error("Error fetching bookmarks:", error);
      res.status(500).json({ message: "Failed to fetch bookmarks" });
    }
  });

  app.post('/api/bookmarks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookmarkData = {
        ...req.body,
        userId,
      };
      
      const bookmark = await storage.createBookmark(bookmarkData);
      res.json(bookmark);
    } catch (error) {
      console.error("Error creating bookmark:", error);
      res.status(500).json({ message: "Failed to create bookmark" });
    }
  });

  app.put('/api/bookmarks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const bookmarkId = parseInt(req.params.id);
      const updates = req.body;
      
      const bookmark = await storage.updateBookmark(bookmarkId, updates);
      res.json(bookmark);
    } catch (error) {
      console.error("Error updating bookmark:", error);
      res.status(500).json({ message: "Failed to update bookmark" });
    }
  });

  app.delete('/api/bookmarks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookmarkId = parseInt(req.params.id);
      
      const success = await storage.deleteBookmark(bookmarkId, userId);
      if (success) {
        res.json({ message: "Bookmark deleted successfully" });
      } else {
        res.status(404).json({ message: "Bookmark not found" });
      }
    } catch (error) {
      console.error("Error deleting bookmark:", error);
      res.status(500).json({ message: "Failed to delete bookmark" });
    }
  });

  app.get('/api/bookmarks/categories', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const categories = await storage.getBookmarkCategories(userId);
      res.json(categories);
    } catch (error) {
      console.error("Error fetching bookmark categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Admin routes
  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const stats = await storage.getSearchStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get('/api/admin/popular-searches', isAuthenticated, async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const popularSearches = await storage.getPopularSearches(limit);
      res.json(popularSearches);
    } catch (error) {
      console.error("Error fetching popular searches:", error);
      res.status(500).json({ message: "Failed to fetch popular searches" });
    }
  });

  app.get('/api/admin/recent-searches', isAuthenticated, async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const recentSearches = await storage.getRecentSearches(limit);
      res.json(recentSearches);
    } catch (error) {
      console.error("Error fetching recent searches:", error);
      res.status(500).json({ message: "Failed to fetch recent searches" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
