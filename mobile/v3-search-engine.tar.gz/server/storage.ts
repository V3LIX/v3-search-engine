import {
  users,
  searchQueries,
  searchResults,
  aiChatSessions,
  savedResults,
  bookmarks,
  type User,
  type UpsertUser,
  type SearchQuery,
  type InsertSearchQuery,
  type SearchResult,
  type InsertSearchResult,
  type AiChatSession,
  type InsertAiChatSession,
  type SavedResult,
  type InsertSavedResult,
  type Bookmark,
  type InsertBookmark,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, count } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  createEmailUser(user: { email: string; firstName: string; lastName: string; passwordHash: string }): Promise<User>;
  
  // Search operations
  createSearchQuery(query: InsertSearchQuery): Promise<SearchQuery>;
  getSearchHistory(userId: string, limit?: number): Promise<SearchQuery[]>;
  getSearchQuery(id: number): Promise<SearchQuery | undefined>;
  
  // Search results operations
  createSearchResults(results: InsertSearchResult[]): Promise<SearchResult[]>;
  getSearchResults(queryId: number): Promise<SearchResult[]>;
  toggleSavedResult(userId: string, resultId: number): Promise<SavedResult | null>;
  getSavedResults(userId: string): Promise<(SavedResult & { result: SearchResult })[]>;
  
  // AI Chat operations
  createAiChatSession(session: InsertAiChatSession): Promise<AiChatSession>;
  updateAiChatSession(id: number, updates: Partial<InsertAiChatSession>): Promise<AiChatSession>;
  getAiChatSession(queryId: number): Promise<AiChatSession | undefined>;
  
  // Bookmarks operations
  createBookmark(bookmark: InsertBookmark): Promise<Bookmark>;
  getBookmarks(userId: string, category?: string): Promise<Bookmark[]>;
  updateBookmark(id: number, updates: Partial<InsertBookmark>): Promise<Bookmark>;
  deleteBookmark(id: number, userId: string): Promise<boolean>;
  getBookmarkCategories(userId: string): Promise<string[]>;
  
  // Admin operations
  getSearchStats(): Promise<{
    totalSearches: number;
    totalUsers: number;
    aiQueries: number;
    indexedPages: number;
  }>;
  getPopularSearches(limit?: number): Promise<{ query: string; count: number }[]>;
  getRecentSearches(limit?: number): Promise<(SearchQuery & { user?: User })[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async createEmailUser(userData: { email: string; firstName: string; lastName: string; passwordHash: string }): Promise<User> {
    const userId = `email_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const [user] = await db
      .insert(users)
      .values({
        id: userId,
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        profileImageUrl: null,
      })
      .returning();
    return user;
  }

  // Search operations
  async createSearchQuery(query: InsertSearchQuery): Promise<SearchQuery> {
    const [searchQuery] = await db
      .insert(searchQueries)
      .values(query)
      .returning();
    return searchQuery;
  }

  async getSearchHistory(userId: string, limit = 50): Promise<SearchQuery[]> {
    return await db
      .select()
      .from(searchQueries)
      .where(eq(searchQueries.userId, userId))
      .orderBy(desc(searchQueries.timestamp))
      .limit(limit);
  }

  async getSearchQuery(id: number): Promise<SearchQuery | undefined> {
    const [query] = await db
      .select()
      .from(searchQueries)
      .where(eq(searchQueries.id, id));
    return query;
  }

  // Search results operations
  async createSearchResults(results: InsertSearchResult[]): Promise<SearchResult[]> {
    if (results.length === 0) return [];
    
    return await db
      .insert(searchResults)
      .values(results)
      .returning();
  }

  async getSearchResults(queryId: number): Promise<SearchResult[]> {
    return await db
      .select()
      .from(searchResults)
      .where(eq(searchResults.queryId, queryId))
      .orderBy(searchResults.rank);
  }

  async toggleSavedResult(userId: string, resultId: number): Promise<SavedResult | null> {
    // Check if already saved
    const [existing] = await db
      .select()
      .from(savedResults)
      .where(and(
        eq(savedResults.userId, userId),
        eq(savedResults.resultId, resultId)
      ));

    if (existing) {
      // Remove from saved
      await db
        .delete(savedResults)
        .where(eq(savedResults.id, existing.id));
      return null;
    } else {
      // Add to saved
      const [saved] = await db
        .insert(savedResults)
        .values({ userId, resultId })
        .returning();
      return saved;
    }
  }

  async getSavedResults(userId: string): Promise<(SavedResult & { result: SearchResult })[]> {
    const results = await db
      .select({
        id: savedResults.id,
        userId: savedResults.userId,
        resultId: savedResults.resultId,
        notes: savedResults.notes,
        tags: savedResults.tags,
        createdAt: savedResults.createdAt,
        result: searchResults
      })
      .from(savedResults)
      .innerJoin(searchResults, eq(savedResults.resultId, searchResults.id))
      .where(eq(savedResults.userId, userId))
      .orderBy(desc(savedResults.createdAt));
    
    return results as (SavedResult & { result: SearchResult })[];
  }

  // AI Chat operations
  async createAiChatSession(session: InsertAiChatSession): Promise<AiChatSession> {
    const [aiSession] = await db
      .insert(aiChatSessions)
      .values(session)
      .returning();
    return aiSession;
  }

  async updateAiChatSession(id: number, updates: Partial<InsertAiChatSession>): Promise<AiChatSession> {
    const [updated] = await db
      .update(aiChatSessions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(aiChatSessions.id, id))
      .returning();
    return updated;
  }

  async getAiChatSession(queryId: number): Promise<AiChatSession | undefined> {
    const [session] = await db
      .select()
      .from(aiChatSessions)
      .where(eq(aiChatSessions.queryId, queryId))
      .orderBy(desc(aiChatSessions.createdAt));
    return session;
  }

  // Admin operations
  async getSearchStats(): Promise<{
    totalSearches: number;
    totalUsers: number;
    aiQueries: number;
    indexedPages: number;
  }> {
    const [searchCount] = await db
      .select({ count: count() })
      .from(searchQueries);

    const [userCount] = await db
      .select({ count: count() })
      .from(users);

    const [aiCount] = await db
      .select({ count: count() })
      .from(aiChatSessions);

    const [indexedCount] = await db
      .select({ count: count() })
      .from(searchResults);

    return {
      totalSearches: searchCount.count,
      totalUsers: userCount.count,
      aiQueries: aiCount.count,
      indexedPages: indexedCount.count,
    };
  }

  async getPopularSearches(limit = 10): Promise<{ query: string; count: number }[]> {
    const results = await db
      .select({
        query: searchQueries.query,
        count: count(),
      })
      .from(searchQueries)
      .groupBy(searchQueries.query)
      .orderBy(desc(count()))
      .limit(limit);

    return results.map(r => ({ query: r.query, count: r.count }));
  }

  async getRecentSearches(limit = 20): Promise<(SearchQuery & { user?: User })[]> {
    const results = await db
      .select({
        id: searchQueries.id,
        query: searchQueries.query,
        filters: searchQueries.filters,
        userId: searchQueries.userId,
        resultsCount: searchQueries.resultsCount,
        timestamp: searchQueries.timestamp,
        user: users
      })
      .from(searchQueries)
      .leftJoin(users, eq(searchQueries.userId, users.id))
      .orderBy(desc(searchQueries.timestamp))
      .limit(limit);
    
    return results as (SearchQuery & { user?: User })[];
  }

  // Bookmarks operations
  async createBookmark(bookmark: InsertBookmark): Promise<Bookmark> {
    const [result] = await db.insert(bookmarks).values(bookmark).returning();
    return result;
  }

  async getBookmarks(userId: string, category?: string): Promise<Bookmark[]> {
    if (category) {
      return await db
        .select()
        .from(bookmarks)
        .where(and(eq(bookmarks.userId, userId), eq(bookmarks.category, category)))
        .orderBy(desc(bookmarks.createdAt));
    }
    
    return await db
      .select()
      .from(bookmarks)
      .where(eq(bookmarks.userId, userId))
      .orderBy(desc(bookmarks.createdAt));
  }

  async updateBookmark(id: number, updates: Partial<InsertBookmark>): Promise<Bookmark> {
    const [result] = await db
      .update(bookmarks)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(bookmarks.id, id))
      .returning();
    return result;
  }

  async deleteBookmark(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(bookmarks)
      .where(and(eq(bookmarks.id, id), eq(bookmarks.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  async getBookmarkCategories(userId: string): Promise<string[]> {
    const results = await db
      .selectDistinct({ category: bookmarks.category })
      .from(bookmarks)
      .where(eq(bookmarks.userId, userId));
    
    return results.map(r => r.category).filter((cat): cat is string => Boolean(cat));
  }
}

export const storage = new DatabaseStorage();
