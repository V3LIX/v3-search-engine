# V3 APK Build Guide - Quick Start

## 🚀 Fast Track to APK Creation

### Step 1: Install Required Tools
```bash
# Install EAS CLI globally (if not already installed)
npm install -g @expo/cli @expo/eas-cli

# Navigate to mobile directory
cd mobile

# Install dependencies
npm install
```

### Step 2: Setup Expo Account
```bash
# Create free Expo account or login
expo login

# Follow prompts to login/register
```

### Step 3: Configure Your App
```bash
# Initialize EAS configuration
eas build:configure

# This creates eas.json file with build profiles
```

### Step 4: Build APK (2 Options)

#### Option A: Development APK (Testing)
```bash
# Build APK for testing (faster, larger file)
eas build --profile preview --platform android --local

# This creates APK you can install directly
```

#### Option B: Production APK (Optimized)
```bash
# Build optimized APK (smaller, takes longer)
eas build --profile production --platform android --local

# This creates release-ready APK
```

### Step 5: Download and Install

1. **EAS will build your APK** (takes 5-10 minutes)
2. **Download the .apk file** from the provided link
3. **Transfer to Android device** via USB, email, or cloud storage
4. **Enable "Install from unknown sources"** in Android settings
5. **Tap the APK file** to install V3 Search Engine

## 📱 APK Features Included

Your APK will have:
- ✅ Complete V3 search functionality
- ✅ User authentication (Google, Microsoft, Email)
- ✅ Bookmarks management
- ✅ Search history
- ✅ All Opera GX-style themes
- ✅ Mobile-optimized interface
- ✅ Offline bookmark access

## 🔧 Troubleshooting

### If build fails:
```bash
# Clear cache and retry
expo r -c
eas build --profile preview --platform android --local --clear-cache
```

### If login issues:
```bash
# Logout and login again
expo logout
expo login
```

### If missing dependencies:
```bash
cd mobile
rm -rf node_modules
npm install
```

## ⚡ Quick Commands Summary

```bash
# 1. Setup (one time)
npm install -g @expo/cli @expo/eas-cli
cd mobile
expo login
eas build:configure

# 2. Build APK
eas build --profile preview --platform android --local

# 3. Install on device
# Download APK → Transfer to phone → Install
```

## 📦 File Output

After successful build:
- **APK Location**: Downloads folder or specified directory
- **File Name**: `V3-[version]-[buildnumber].apk`
- **Size**: ~50-100MB depending on build type

## 🚀 Next Steps After APK

1. **Test APK** on your Android device
2. **Share with others** for testing
3. **Upload to Google Play** (optional, requires developer account)
4. **Create desktop app** (next step)

Your APK is completely independent and works without internet for saved bookmarks and history!