# V3 Desktop App Creation Guide

## 🖥️ Creating Desktop App with Electron

### Method 1: Electron (Recommended)

#### Step 1: Install Electron
```bash
npm install --save-dev electron electron-builder
```

#### Step 2: Create Desktop App Files

**package.json additions:**
```json
{
  "main": "desktop/main.js",
  "scripts": {
    "electron": "electron .",
    "electron-dev": "electron . --dev",
    "build-desktop": "electron-builder",
    "dist": "npm run build && electron-builder"
  },
  "build": {
    "appId": "com.v3lix.search",
    "productName": "V3 Search Engine",
    "directories": {
      "output": "dist-desktop"
    },
    "files": [
      "dist/**/*",
      "desktop/main.js",
      "desktop/preload.js"
    ],
    "mac": {
      "icon": "desktop/assets/icon.icns"
    },
    "win": {
      "icon": "desktop/assets/icon.ico"
    },
    "linux": {
      "icon": "desktop/assets/icon.png"
    }
  }
}
```

**desktop/main.js:**
```javascript
const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
const isDev = process.argv.includes('--dev');

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, 'assets/icon.png'),
    titleBarStyle: 'default',
    show: false
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5000');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/public/index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Create application menu
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'New Search',
          accelerator: 'CmdOrCtrl+N',
          click: () => {
            mainWindow.webContents.executeJavaScript('document.querySelector("input[type=search]")?.focus()');
          }
        },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Window',
      submenu: [
        { role: 'minimize' },
        { role: 'close' }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
```

**desktop/preload.js:**
```javascript
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  platform: process.platform,
  isElectron: true
});
```

#### Step 3: Build Desktop App

```bash
# Development
npm run electron-dev

# Build for distribution
npm run build
npm run build-desktop

# This creates installers in dist-desktop/
```

### Method 2: PWA Desktop Installation

Your web app is already PWA-ready! Users can install it as a desktop app:

1. **Visit your deployed web app**
2. **Click browser menu** → "Install V3 Search Engine"
3. **App appears in start menu/applications**
4. **Runs in its own window**

## 🏗️ Building Process

### For Windows:
- Creates `.exe` installer
- Users double-click to install
- App appears in Start Menu

### For macOS:
- Creates `.dmg` file
- Users drag to Applications folder
- App appears in Launchpad

### For Linux:
- Creates `.AppImage` or `.deb` files
- Users can run directly or install

## 📦 Distribution

1. **GitHub Releases** - Upload installers for free download
2. **Microsoft Store** - Submit for Windows users
3. **Mac App Store** - Submit for macOS users
4. **Direct Download** - Host files on your website

## 🎨 App Icons

Create icons in these sizes:
- **icon.ico** (Windows) - 256x256
- **icon.icns** (macOS) - 512x512
- **icon.png** (Linux) - 512x512

Your desktop app will include:
- Full V3 search functionality
- Bookmarks and history
- All themes and backgrounds
- Native desktop integration
- System notifications
- Keyboard shortcuts